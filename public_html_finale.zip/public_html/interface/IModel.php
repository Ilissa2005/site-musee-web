<?php
namespace interfaces;

interface IModel
{
    public function insert($objet);
    public function delete($objet);
    public function update($objet);
}
?>