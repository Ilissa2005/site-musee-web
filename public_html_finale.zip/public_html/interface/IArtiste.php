<?php
namespace interfaces;

interface IArtiste
{
    public function listeOeuvre();
    public function exposer();
    public function existe();
}