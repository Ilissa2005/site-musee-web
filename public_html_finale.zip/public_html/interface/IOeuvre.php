<?php
namespace interfaces;

interface IOeuvre
{
    public function exposer();
    public function existe();
}