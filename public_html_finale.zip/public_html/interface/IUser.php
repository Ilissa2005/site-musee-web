<?php
namespace interfaces;

interface IUser
{
    public function voirProfil();
    public function voirOeuvre();
    public function voirArtiste();
    public function verifierMotDePasse($mdp);
}
?>