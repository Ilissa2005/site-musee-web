

<main class="container mt-4">
    <header>
        Vous êtes sur la page <?php echo $pageariane; ?>
    </header>

    <h2>Modifier mon profil</h2>

    <?php if ($erreur != "") { ?>
        <div class="alert alert-danger mt-3"><?php echo htmlspecialchars($erreur); ?></div>
    <?php } ?>

    <?php if ($message != "") { ?>
        <div class="alert alert-success mt-3"><?php echo htmlspecialchars($message); ?></div>
    <?php } ?>

    <div class="card p-4 mt-3">
        <form action="modifier" method="post">
                     <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">

            <div class="mb-3">
                <label for="nom" class="form-label">Nom</label>
                <input type="text" name="nom" id="nom" class="form-control" value="<?php echo htmlspecialchars($nom); ?>">
            </div>

            <div class="mb-3">
                <label for="prenom" class="form-label">Prénom</label>
                <input type="text" name="prenom" id="prenom" class="form-control" value="<?php echo htmlspecialchars($prenom); ?>">
            </div>

            <div class="mb-3">
                <label for="mail" class="form-label">Mail</label>
                <input type="email" name="mail" id="mail" class="form-control" value="<?php echo htmlspecialchars($mail); ?>">
            </div>

            <div class="mb-3">
                <label for="ancien_mdp" class="form-label">Mot de passe actuel</label>
                <input type="password" name="ancien_mdp" id="ancien_mdp" class="form-control">
            </div>

            <div class="mb-3">
                <label for="nouveau_mdp" class="form-label">Nouveau mot de passe</label>
                <input type="password" name="nouveau_mdp" id="nouveau_mdp" class="form-control">
                <small>Laisse vide si tu ne veux pas le changer.</small>
            </div>

            <div class="mt-3">
                <button type="submit" class="btn btn-primary">Enregistrer les modifications</button>
                <a href="profil" class="btn btn-secondary">Retour au profil</a>
            </div>
        </form>
    </div>
</main>

<?php include("footer.php"); ?>