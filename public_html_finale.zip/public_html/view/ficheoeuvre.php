<h2><?php echo $titre_oeuvre; ?></h2>

<img class="fiche-image" 
     src="<?php echo $lien_image_oeuvre; ?>" 
     alt="Image oeuvre">

<div><?php echo $description_oeuvre; ?></div>