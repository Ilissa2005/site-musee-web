<p><?php echo $message; ?></p>
<p><a href="<?php echo $r; ?>">Retour</a></p>