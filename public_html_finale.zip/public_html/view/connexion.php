<main class="container mt-4">
    <h2>Connexion</h2>

    <?php if ($erreur != "") { ?>
        <div class="alert alert-danger">
            <?php echo htmlspecialchars($erreur); ?>
        </div>
    <?php } ?>

    <form method="post">
         <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
        <p>
            <label>Email</label>
            <input type="email" name="email" class="form-control" required>
        </p>

        <p>
            <label>Mot de passe</label>
            <input type="password" name="mdp" class="form-control" required>
        </p>

        <button type="submit" class="btn btn-primary">Se connecter</button>
    </form>
</main>