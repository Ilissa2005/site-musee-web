<?php include("header.php"); ?>

<main class="container mt-4">
    <header>
        Vous êtes sur la page <?php echo $pageariane; ?>
    </header>

    <h2>Mon profil</h2>

    <?php if ($erreur != "") { ?>
        <div class="alert alert-danger mt-3">
            <?php echo htmlspecialchars($erreur); ?>
        </div>
    <?php } else { ?>

        <form>
             <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
            <p>
                <label>Nom</label>
                <input type="text" value="<?php echo htmlspecialchars($nom); ?>" readonly class="form-control">
            </p>

            <p>
                <label>Prénom</label>
                <input type="text" value="<?php echo htmlspecialchars($prenom); ?>" readonly class="form-control">
            </p>

            <p>
                <label>Email</label>
                <input type="email" value="<?php echo htmlspecialchars($mail); ?>" readonly class="form-control">
            </p>

            <p>
                <label>Rôle</label>
                <input type="text" value="<?php echo htmlspecialchars($role); ?>" readonly class="form-control">
            </p>

            <p class="mt-3">
                <a href="<?php echo $lien_modifier; ?>" class="btn btn-primary">Modifier</a>
                <a href="<?php echo $lien_supprimer; ?>" class="btn btn-danger">Supprimer</a>
            </p>
        </form>

    <?php } ?>
</main>

<?php include("footer.php"); ?>