<main class="container mt-4">
    <header>
        <h2>Confirmation de déconnexion</h2>
    </header>

    <form method="POST" action="deconnexion">
        <p>Pour confirmer votre déconnexion, veuillez entrer votre mot de passe :</p>
    <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
        <?php if (!empty($erreur)) { ?>
            <div class="alert alert-danger"><?php echo $erreur; ?></div>
        <?php } ?>

        <div class="mb-3">
            <label for="mdp" class="form-label">Mot de passe</label>
            <input type="password" class="form-control" id="mdp" name="mdp" required>
        </div>

        <button type="submit" class="btn btn-danger">Confirmer la déconnexion</button>
    </form>
</main>