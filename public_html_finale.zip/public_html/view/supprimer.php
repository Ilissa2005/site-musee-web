<?php include("header.php"); ?>

<main class="container mt-4">
    <header>
        Vous êtes sur la page <?php echo $pageariane; ?>
    </header>

    <h2>Supprimer mon compte</h2>

    <?php if ($erreur != "") { ?>
        <div class="alert alert-danger mt-3"><?php echo htmlspecialchars($erreur); ?></div>
    <?php } ?>

    <div class="card p-4 mt-3">
        <form action="" method="post">
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">

            <div class="mb-3">
                <label for="mdp" class="form-label">Mot de passe</label>
                <input type="password" name="mdp" id="mdp" class="form-control">
            </div>

            <div class="mb-3">
                <label for="confirmation" class="form-label">Confirmation</label>
                <select name="confirmation" id="confirmation" class="form-control">
                    <option value="">Choisir</option>
                    <option value="oui">Oui, je veux supprimer mon compte</option>
                </select>
            </div>

            <div class="mt-3">
                <button type="submit" class="btn btn-danger">Supprimer définitivement</button>
                <a href="profil" class="btn btn-secondary">Annuler</a>
            </div>
        </form>
    </div>
</main>

<?php include("footer.php"); ?>