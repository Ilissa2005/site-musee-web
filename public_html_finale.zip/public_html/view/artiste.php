<div class="col-md-4 mb-4">
    <div class="card h-100">
        <img src="<?php echo $lien_image_artiste; ?>" class="card-img-top" alt="<?php echo $prenom_artiste . ' ' . $nom_artiste; ?>">
        <div class="card-body">
            <h5 class="card-title"><?php echo $prenom_artiste . ' ' . $nom_artiste; ?></h5>
            <a class="btn btn-primary" href="<?php echo $lien_fiche_artiste; ?>">Voir la fiche</a>
        </div>
    </div>
</div>