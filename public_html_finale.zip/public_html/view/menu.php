<?php

$role = $_SESSION['user']['role'] ?? 'guest';
$perso = $_COOKIE['cookie_perso'] ?? '0';
$m = "bg-light";

if ($perso) {
    if ($role == "admin") {
        $m = "menu-admin";
    } elseif ($role == "user") {
        $m = "menu-user";
    }
}
?>

<nav class="navbar <?php echo $m; ?>">
    <div class="container-fluid">
        <a class="navbar-brand" href="accueil">Accueil</a>
        <a class="navbar-brand" href="oeuvre">Œuvres</a>
        <a class="navbar-brand" href="artiste">Artistes</a>
        <a class="navbar-brand" href="contact">Contact</a>
        <a class="navbar-brand" href="sitemap.html">Plan du site</a>
        <a class="navbar-brand" href="mentions">Réglementations</a>
        <a class="navbar-brand" href="profil">Profil</a>
        <a class="navbar-brand" href="connexion">Connexion</a>
        <a class="navbar-brand" href="deconnexion">Déconnexion</a>
    </div>
</nav>