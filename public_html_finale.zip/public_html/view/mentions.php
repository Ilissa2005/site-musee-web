<main class="container mt-4">
    <header>
        <h2>Mentions légales</h2>
    </header>

    <div class="content-box border p-4 rounded">
        <h3>Mentions légales : réglementation et conditions d’utilisation</h3>

        <br> <!-- Espacement entre le grand titre et les sections suivantes -->

        <h4>1. Propriétaire et responsable de publication</h4>
        <p>
            Le site **Musée Histoire des Œuvres** a été créé par **Ilissa INGRACHEN** et **Afkir Afkir Hafsa**. Ils en sont les responsables de publication et en assurent le bon fonctionnement.
        </p>

        <br> <!-- Espacement entre les sections -->

        <h4>2. Propriété intellectuelle</h4>
        <p>
            L'ensemble du contenu présent sur ce site (textes, images, vidéos, logos, etc.) est protégé par les lois françaises et internationales sur la propriété intellectuelle. 
            Les éléments contenus sur ce site sont la propriété exclusive de **Ilissa INGRACHEN** et **Afkir Afkir Hafsa** ou de leurs partenaires. Toute reproduction ou utilisation non autorisée des éléments présents sur ce site est interdite sans l'accord préalable des responsables de publication.
            En outre, les marques, logos, et autres signes distinctifs utilisés sur ce site sont protégés par des droits de propriété industrielle. Leur reproduction ou utilisation sans autorisation préalable est interdite.
        </p>

        <br>

        <h4>3. Données personnelles (RGPD)</h4>
        <p>
            En conformité avec le Règlement Général sur la Protection des Données (RGPD), ce site respecte la confidentialité des données personnelles. Les informations collectées via le site (formulaires de contact, inscription, etc.) sont utilisées exclusivement dans le cadre des services proposés. 
            Nous nous engageons à ne jamais transmettre ces données à des tiers, sauf si cela est nécessaire pour fournir le service ou en vertu de la loi.
            Les utilisateurs disposent d’un droit d’accès, de rectification, de suppression et d’opposition concernant leurs données personnelles. Pour exercer ces droits, les utilisateurs peuvent contacter le responsable du traitement des données à l'adresse suivante : 
            <strong>ingrachenilissa@gmail.com</strong><br>
            <strong>hafsa.afkir-afkir@alumni.univ-avignon.fr</strong>
        </p>

        <br>

        <h4>4. Cookies</h4>
        <p>
            Ce site utilise des cookies afin de garantir un fonctionnement optimal et une meilleure expérience utilisateur. Les cookies sont utilisés à des fins de performance, d’analyse du trafic et de personnalisation du contenu. 
            Vous avez la possibilité de configurer votre navigateur pour refuser les cookies. Cependant, certaines fonctionnalités du site peuvent ne pas fonctionner correctement si vous choisissez de refuser les cookies.
            Des cookies optionnels (statistiques et personnalisation) peuvent également être utilisés si vous consentez à leur utilisation. Vous pouvez gérer vos préférences en matière de cookies à tout moment.
        </p>

        <br>

        <h4>5. Limitation de responsabilité</h4>
        <p>
            Le contenu diffusé sur ce site est fourni à titre informatif. **Ilissa INGRACHEN** et **Afkir Afkir Hafsa** mettent tout en œuvre pour garantir la véracité des informations, mais ne peuvent être tenus responsables des erreurs, omissions ou de la mise à jour des informations. 
            L’utilisation du site se fait sous la seule responsabilité de l’utilisateur. L’éditeur du site ne saurait être tenu responsable des éventuels dommages directs ou indirects causés par l’utilisation du site, tels que la perte de données, de profits ou toute autre perte.
        </p>

        <br>

        <h4>6. Conditions d’utilisation</h4>
        <p>
            L’utilisateur s’engage à utiliser ce site conformément à la législation en vigueur. Toute utilisation frauduleuse ou abusive de ce site (notamment toute tentative de piratage ou d’attaque informatique) sera sanctionnée par les lois applicables.
            Les responsables de publication se réservent également le droit de suspendre, modifier, ou supprimer l'accès au site en cas de non-respect des présentes conditions d’utilisation.
        </p>

        <br>

        <h4>7. Modification des mentions légales</h4>
        <p>
            **Ilissa INGRACHEN** et **Afkir Afkir Hafsa** se réservent le droit de modifier à tout moment les présentes mentions légales. Toute modification sera publiée sur cette page et sera effective dès sa mise en ligne.
            L’utilisation continue du site après ces modifications implique l’acceptation des nouvelles mentions légales.
        </p>

        <br>

        <h4>8. Loi applicable et juridiction compétente</h4>
        <p>
            Ces mentions légales sont régies par la loi française. En cas de litige, la juridiction compétente sera celle de la ville d'Avignon, sauf disposition contraire.
        </p>

        <br>

        <h4>9. Responsabilité en matière de liens externes</h4>
        <p>
            Ce site peut contenir des liens vers d’autres sites. **Ilissa INGRACHEN** et **Afkir Afkir Hafsa** ne peuvent être tenus responsables du contenu de ces sites externes et des pratiques de confidentialité qui y sont appliquées. 
            Il est recommandé aux utilisateurs de consulter les mentions légales et la politique de confidentialité des sites tiers avant d'y fournir des informations personnelles.
        </p>

        <br>

        <h4>10. Force majeure</h4>
        <p>
            **Ilissa INGRACHEN** et **Afkir Afkir Hafsa** ne pourront être tenus responsables en cas de force majeure ou d’événements imprévus tels que grèves, défaillances techniques, catastrophes naturelles, ou autres événements indépendants de leur volonté qui empêcheraient l’accès au site ou sa bonne utilisation.
        </p>
    </div>
</main>