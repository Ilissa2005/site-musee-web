<footer class="pied-page mt-4 p-3 bg-light">
    <p>© 2026 - Musée Histoire des Œuvres</p>

    <p>
        <a href="/mentions">Mentions légales</a> |
        <a href="/plan-du-site">Plan du site</a> |
    <a href="#" onclick="document.getElementById('cookie-modal').style.display='block';return false;">
        Modifier mes cookies
    </a>
</p>
    </p>

    <p>
        <a href="https://www.youtube.com" target="_blank">YouTube</a> |
        <a href="https://www.instagram.com" target="_blank">Instagram</a> |
        <a href="https://www.tiktok.com" target="_blank">TikTok</a> |
        <a href="https://www.twitter.com" target="_blank">Twitter</a>
    </p>
</footer>

</body>
</html>