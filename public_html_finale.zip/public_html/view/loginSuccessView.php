<p>Connexion réussie.</p>
<p><a href="<?php echo $racine_path . "control/" . $a; ?>">Voir mon profil</a></p>