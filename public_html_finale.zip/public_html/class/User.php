<?php
namespace classes;
use interfaces\IUser;
use models\OeuvreModel;
use models\ArtisteModel;
class User implements IUser
{
    public $id;//id doit commence par 1
    public $nom;
    public $prenom;
    public $email;
    private $mdp;
    public $role;
    public $image;
    public static $nb_users = 0;
    const TYPE = "user";

    public function __construct($id ,$nom = "", $prenom = "", $email = "", $mdp = "", $role = "user", $image = "")
    {
        $this->id = $id;
        $this->nom = $nom;
        $this->prenom = $prenom;
        $this->email = $email;
        $this->mdp = $mdp;
        $this->role = $role;
        $this->image = $image;
        self::$nb_users++;
    }

    public function voirProfil()
    {
        return [
        "nom" => $this->nom,
        "prenom" => $this->prenom,
        "email" => $this->email,
        "role" => $this->role
    ];
    }
     public function voirOeuvre(){
        $model = new OeuvreModel();
        return $model->getAll();
    }
    public function voirArtiste(){
        $model = new ArtisteModel();
        return $model->getAll();
    }
    public function verifierMotDePasse($mdp)
    {
        return password_verify($mdp, $this->mdp);
    }

    public function __toString()
    {
        return $this->prenom . " " . $this->nom . " - " . $this->email;
    }

    public function __get($attr)
    {
        if (property_exists($this, $attr)) {
            return $this->$attr;
        }
        return null;
    }

    public function __set($attr, $val)
    {
        if (property_exists($this, $attr)) {
            $this->$attr = $val;
        }
    }
}