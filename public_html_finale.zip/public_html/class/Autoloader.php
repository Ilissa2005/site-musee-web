<?php

class Autoloader {
     /**
     * Appel de spl_autoload_register
	 *
	 * @return null
     */
    public static function enregistrer() {
        spl_autoload_register([__CLASS__, 'autoload']);
    }
    /**
     * Charge les fichiers des classes instanciées
	 * separe le namespace et le nom de fichier
	 * @param	nom de la classe à instancier
	 * @return 	null
     */
    public static function autoload($nom_class) {
        // Convertit les namespaces en chemins
        $nom_class = str_replace('\\', '/', $nom_class);

        // Mapping namespace , dossier
         $paths = [
            'classes/'    => __DIR__ . '/',
            'model/'      =>  __DIR__ . '/../model/',
            'interfaces/' =>  __DIR__ . '/../interface/',
            'exception/' =>  __DIR__ . '/../exception/'  
        ];
        foreach ($paths as $path => $dir) {
            // Si la classe commence par ce namespace
            if (strpos($nom_class, $path) === 0) {
                // On sup le namespace pour garder juste le nom de fichier
                $relative = substr($nom_class, strlen($path));
                // Chemin final
                $file = $dir . $relative . '.php';
                if (file_exists($file)) {
                     require $file;
                    return;
                }
            }
        }
    }
}
