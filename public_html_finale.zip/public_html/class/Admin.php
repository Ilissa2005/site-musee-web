<?php
namespace classes;
use model\UtilisateurModel;

class Admin extends User 
{
    public function __construct($id = 0, $nom = "", $prenom = "", $mail = "", $mdp = "", $role = "admin", $image = "")
    {
        parent::__construct($id, $nom, $prenom, $mail, $mdp, $role, $image);
    }

    // Gestion des œuvres
    /**
     * @param Oeuvre $objet
     * 
     * @return [type]
     */
    public function addOeuvre(Oeuvre $objet)
    {
        $model = new ArtisteModel();
        return $model->insert($objet);
    }

    public function delOeuvre(Oeuvre $objet)
    {
         $model = new ArtisteModel();
        return $model->delete($objet->id);
    }

    public function modifierOeuvre(Oeuvre $objet)
    {
         $model = new ArtisteModel();
        return $model->update($objet);
    }

    // Gestion des artistes
    public function addArtiste($objet)
    {
        $model = new ArtisteModel();
        return $model->insert($objet);
    }

    public function delArtiste(Artiste $objet)
    {
        $model = new ArtisteModel();
        return $model->update($objet);
    }

    public function modifierArtiste(Artiste $objet)
    {
        $model = new ArtisteModel();
        return $model->update($objet);
    }

    // Gestion des utilisateurs
    public function modifierUser(User $objet)
    {
        $model = new UtilisateurModel();
        return $model->update($objet);
    }

    public function supUser(User $objet)
    {
        $model = new UtilisateurModel();
        return $model->delete($objet->id);
    }
    /**
     * @param User $objet
     * 
     * @return [type]
     */
    public function ajouterUser(User $objet)
    {
        $model = new UtilisateurModel();
        return $model->insert($objet);
    }
    public function voirProfil()
    {
        return [
        "nom" => $this->nom,
        "prenom" => $this->prenom,
        "email" => $this->email,
        "role" => $this->role
    ];
    }
    public function verifierMotDePasse($mdp)
    {
        return password_verify($mdp, $this->mdp);
    }
}
?>