<?php
namespace classes;

use interfaces\IArtiste;

class Artiste implements IArtiste
{
    public $id;
    public $nom;
    public $prenom;
    private $bio;
    public $image;
    public static $nb_artistes = 0;
    const TYPE = "artiste";

    public function __construct($id , $nom = "", $prenom = "", $bio = "", $image = "")
    {
        $this->id = $id;
        $this->nom = $nom;
        $this->prenom = $prenom;
        $this->bio = $bio;
        $this->image = $image;
        self::$nb_artistes++;
    }

    public function existe()
        {
           return true;
        }
    public function exposer()
        {
            return true;
        }
    public static function combien()
    {
        return self::$nb_artistes;
    }

    public function listeOeuvre()
    {
        return [];
    }

    public function __toString()
    {
        return $this->prenom . " " . $this->nom;
    }

    public function __get($attr)
    {
        if (property_exists($this, $attr)) {
            return $this->$attr;
        }
        return null;
    }

    public function __set($attr, $val)
    {
        if (property_exists($this, $attr)) {
            $this->$attr = $val;
        }
    }
}