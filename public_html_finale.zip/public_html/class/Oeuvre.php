<?php
namespace classes;

use interfaces\IOeuvre;

class Oeuvre implements IOeuvre
{
    public $id;
    public $titre;
    protected $type;
    private $date_creation;
    private $auteur;
    protected $description;
    public $image;
    public static $nb_oeuvres = 0;
    const TYPE = "oeuvre";

    public function __construct($id = 0, $titre = "", $type = "", $date_creation = "", $auteur = 0,$description = "", $image = ""   )
    {
        $this->id = $id;
        $this->titre = $titre;
        $this->type = $type;
        $this->description = $description;
        $this->image = $image;
        $this->date_creation = $date_creation;
        $this->auteur = $auteur;
        self::$nb_oeuvres++;
    }

    public static function combien()
    {
        return self::$nb_oeuvres;
    }
    public function existe()
    {
        return true;
    }
    public function exposer()
    {
        return true;
    }
    public function __toString()
    {
        return $this->titre . " - " . $this->date_creation;
    }

    public function __get($attr)
    {
        if (property_exists($this, $attr)) {
            return $this->$attr;
        }
        return null;
    }

    public function __set($attr, $val)
    {
        if (property_exists($this, $attr)) {
            $this->$attr = $val;
        }
    }
}