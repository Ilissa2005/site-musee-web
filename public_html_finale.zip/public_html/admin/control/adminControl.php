<?php
/**
 * Contrôleur de la page de profil.
 * Permet à l'utilisateur connecté de voir ses informations et de les modifier.
 *
 * Ce fichier récupère les informations de l'utilisateur connecté à partir de la session, 
 * telles que le nom, prénom, email, et image. Il fournit également un lien pour modifier 
 * le profil de l'utilisateur.
 * 
 * @category Controller
 * @package Musée
 * @author Ilissa Ingrachen, Afkir Hafsa
 * @version 1.0
 * 
 * @throws UtilisateurException Si l'utilisateur n'est pas trouvé.
 */
require_once __DIR__ . '/../../class/Autoloader.php';
session_start();
Autoloader::enregistrer();
use model\UtilisateurModel;
use classes\User;

$racine_path = '../';  // Définition du chemin de base
$titre = "Mon Profil - Musée Histoire des Œuvres";  // Titre de la page
$pageariane = "Mon profil";  // Titre affiché dans le fil d'Ariane

// Inclusion de l'en-tête de la page
/*view*/ include($racine_path."view/header.php");

echo '<main>';
echo "<header> Mon fil d'ariane -> vous êtes sur la page $pageariane </header>";

// Création de l'instance du modèle Utilisateur
$model = new UtilisateurModel();

// Récupération de l'ID de l'utilisateur depuis la session
$id = $_SESSION['id'];

// Recherche des informations de l'utilisateur dans la base de données
$user = $model->chercherParId($id);

// Assignation des informations de l'utilisateur à des variables
$nom = $user->nom;
$prenom = $user->prenom;
$email = $user->email;
$mdp = '***********';  // Masquage du mot de passe
$image = $user->image;

// Lien pour modifier le profil
$modifier = $racine_path . 'admin/modifier-' . $id . '-user';

// Inclusion de la vue pour afficher les informations de l'utilisateur
/*view*/ include($racine_path."view/profilView.php");

echo '</main>';

// Inclusion du pied de page
/*view*/ include($racine_path."view/footer.php");

?>