<?php
/**
 * Contrôleur pour la page d'accueil du site Musée Histoire des Œuvres.
 * Gère l'affichage de la page d'accueil et le comptage des visites.
 *
 * @category Contrôleur
 * @package Musée
 * @author Ilissa Ingrachen, Afkir Hafsa
 * @version 1.0
 */

$titre = "Accueil - Musée Histoire des Œuvres"; // Titre de la page
$pageariane = "Accueil"; // Nom de la page dans le menu
$racine_path = '../'; // Chemin de base pour les includes
session_start(); // Démarrage de la session

// Chargement des classes via l'autoloader
require __DIR__ . "/../../class/Autoloader.php";
Autoloader::enregistrer();

// Utilisation des modèles nécessaires pour les artistes et œuvres
use model\ArtisteModel;
use model\OeuvreModel;
use classes\Artiste;
use classes\Oeuvre;

// Calcul du nombre de pages vues, en utilisant les cookies et la session
if (!empty($_COOKIE['cookie_stats']) && $_COOKIE['cookie_stats'] === "1") {
    if (!isset($_SESSION['page_views'])) {
        $_SESSION['page_views'] = 0; // Initialisation du compteur de vues
    }
    $_SESSION['page_views']++; // Incrémentation du compteur
    $nbr_visiteur = $_SESSION['page_views']; // Nombre de visites
} else {
    $nbr_visiteur = "Statistiques désactivées"; // Message si les statistiques sont désactivées
}

// Chargement des artistes et œuvres pour affichage sur la page d'accueil
$artisteModel = new ArtisteModel();
$artistes = $artisteModel->chercherAll(); // Récupère tous les artistes
$nbArtistes = Artiste::combien(); // Nombre total d'artistes
$oeuvreModel = new OeuvreModel();
$oeuvres = $oeuvreModel->chercherAll(); // Récupère toutes les œuvres
$nbOeuvres = Oeuvre::combien(); // Nombre total d'œuvres

/*view*/  
include($racine_path.'view/header.php'); // Inclusion du header
echo '<main>'; 
/*view*/  
include($racine_path.'view/accueilV.php'); // Inclusion du contenu de la page d'accueil
echo '</main>'; 

include($racine_path.'view/footer.php'); // Inclusion du footer
?>