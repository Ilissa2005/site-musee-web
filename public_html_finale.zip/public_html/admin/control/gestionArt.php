<?php
/**
 * Contrôleur de gestion des artistes.
 * Permet l'ajout, la mise à jour et la suppression d'artistes via un formulaire.
 * 
 * @category Controller
 * @package Musée
 * @author Ilissa Ingrachen, Afkir Hafsa
 * @version 1.0
 */

// Inclusion des fichiers nécessaires et initialisation des variables
$titre = "Accueil - Musée Histoire des Œuvres";
$pageariane = "Accueil"; 
$racine_path = '../';	
/*view*/  include($racine_path.'view/header.php');
echo '<main>'; 
require_once '../../class/Autoloader.php';
Autoloader::enregistrer();

// Déclaration des classes utilisées
use model\ArtisteModel;
use classes\Artiste;

// Instanciation du modèle
$model = new ArtisteModel();

// Vérification du token CSRF
if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
    throw new Exception("Erreur CSRF : requête invalide.");

}

// INSERT : Ajout d'un artiste
if ($_POST['action'] === 'insert') {
    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $bio = $_POST['bio'];
    
    // Création de l'artiste avec id = 0 car il sera auto-incrémenté
    $artiste = new Artiste(0, $nom, $prenom, $bio);
    $imageName = null;

    // Gestion de l'upload d'image
    if (!empty($_FILES['image']['name'])) {
        $imageName = $_FILES['image']['name'];
        move_uploaded_file($_FILES['image']['tmp_name'], "../../images/" . $imageName);
    }

    // Assignation de l'image à l'artiste et insertion dans la base
    $artiste->image = $imageName;
    $model->insert($artiste);
    echo "Artiste inséré : " . $artiste->prenom . " " . $artiste->nom;
}

// UPDATE : Mise à jour d'un artiste
if ($_POST['action'] === 'update') {
    $id = $_POST['id'];
    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $bio = $_POST['bio'];

    // Création de l'artiste avec les nouvelles informations
    $imageName = null;
    if (!empty($_FILES['image']['name'])) {
        $imageName = $id . "_" . $_FILES['image']['name'];
        move_uploaded_file($_FILES['image']['tmp_name'], "../../images/" . $imageName);
    }

    // Mise à jour de l'artiste
    $artiste = new Artiste($id, $nom, $prenom, $bio);
    $artiste->image = $imageName;
    $model->update($artiste);
    echo "Artiste modifié : " . $artiste->prenom . " " . $artiste->nom;
}

// DELETE : Suppression d'un artiste
if ($_POST['action'] === 'delete') {
    $id = $_GET['id'];
    $choix = $_POST['choix'];

    // Vérification de la suppression
    if ($choix === "oui") {
        $model->delete($id);
        echo "Artiste supprimé";
    } else {
        echo "Suppression annulée";
    }
}

echo '</main>'; 

// Inclusion du footer
include($racine_path.'view/footer.php');
?>