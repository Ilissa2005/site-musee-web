<?php
/**
 * Contrôleur de la page Artistes.
 * Gère l'affichage des informations sur les artistes ainsi que l'ajout, la modification et la suppression d'artistes.
 * 
 * Ce fichier récupère les informations des artistes depuis la base de données et les affiche sur la page. 
 * Il permet également d'ajouter, modifier et supprimer des artistes.
 *
 * @category Controller
 * @package Musée
 * @author Ilissa Ingrachen, Afkir Hafsa
 * @version 1.0
 */
session_start();
require_once "../../class/Autoloader.php";
Autoloader::enregistrer();
use model\ArtisteModel;

$racine_path = '../';  // Chemin de base
$titre = "Artiste-Musée Histoire des Œuvres";  // Titre de la page
$pageariane = "Artiste";  // Fil d'ariane

// Inclusion du header
include($racine_path."view/header.php");

echo '<main>';
echo "<header> Mon fil d'ariane -> vous êtes sur la page $pageariane </header>";

// Instanciation du modèle Artiste
$model = new ArtisteModel();
$artistes = $model->chercherAll();  // Récupération de tous les artistes

// Bouton pour ajouter un artiste
echo '<a href="../admin/ajouter-0-artiste" class="btn btn-success" style="margin: 20px;">Ajouter un Artiste</a>';
echo '<div class="cards-container">';

// Affichage des artistes dans une boucle
foreach ($artistes as $artiste) {
    $id = $artiste->id;
    $nom = $artiste->nom;
    $prenom = $artiste->prenom;
    $bio = $artiste->bio;
    $image = $artiste->image;
    $modifier = $racine_path.'admin/modifier-'.$id.'-artiste';
    $sup = $racine_path.'admin/sup-'.$id.'-artiste';
    include($racine_path."view/artistes.php");  // Inclusion de la vue pour chaque artiste
}

echo '</div>';
echo '</main>';

// Inclusion du footer
include($racine_path."view/footer.php");
?>