<?php
/**
 * Contrôleur de déconnexion.
 * Supprime toutes les variables de session et détruit la session de l'utilisateur.
 * L'utilisateur est ensuite redirigé vers la page d'accueil.
 * 
 * @category Controller
 * @package Musée
 * @author Ilissa Ingrachen, Afkir Hafsa
 * @version 1.0
 */

// Démarre la session
session_start();
setcookie("cookie_consent", "", time() - 3600, "/");
// Supprime toutes les variables de session
session_unset();

// Détruit la session
session_destroy();

// Redirige l'utilisateur vers la page d'accueil après la déconnexion
header("Location: ../accueil");
exit();

?>