<?php
/**
 * Contrôleur pour la suppression d'une œuvre, d'un artiste ou d'un utilisateur.
 * Ce fichier gère la suppression des éléments (œuvre, artiste, utilisateur) à partir de l'ID passé dans l'URL.
 * Il affiche un message de confirmation avant d'effectuer la suppression.
 * 
 * @category Controller
 * @package Musée
 * @author Ilissa Ingrachen, Afkir Hafsa
 * @version 1.0
 */

$racine_path = '../';  // Définition du chemin racine pour inclure les vues
$titre = "Suprimer";  // Titre de la page

include($racine_path . "view/header.php");  // Inclusion de l'en-tête

// Récupération des paramètres GET
$type = $_GET["type"];  
$id = $_GET["id"];  // Récupération de l'ID de l'élément à supprimer

// Message selon le type d'élément à supprimer
echo '<main>';
if ($type === "oeuvre") { 
    $message = "L'oeuvre avec l'id $id va être supprimée"; 
    $revenir = $racine_path . "admin/gestionOeu-" . $id . "-user"; 
} elseif ($type === "artiste") { 
    $message = "L'auteur avec l'id $id va être supprimé"; 
    $revenir = $racine_path . "admin/gestionArt-" . $id . "-user"; 
} elseif($type === "user") {
    $message = "L'utilisateur avec l'id $id va être supprimé";
    $revenir = $racine_path . "admin/gestion-" . $id . "-user";
}

// Inclusion de la vue pour afficher le message de suppression
include($racine_path . "view/supV.php");

echo '</main>';  // Fin de la partie principale de la page

include($racine_path . "view/footer.php");  // Inclusion du pied de page
?>