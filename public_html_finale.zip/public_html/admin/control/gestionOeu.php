<?php
/**
 * Contrôleur de gestion des œuvres.
 * Permet d'ajouter, modifier et supprimer des œuvres via des formulaires.
 * 
 * @category Controller
 * @package Musée
 * @author Ilissa Ingrachen, Afkir Hafsa
 * @version 1.0
 */

$titre = "Accueil - Musée Histoire des Œuvres"; // Titre de la page
$pageariane = "Accueil"; // Fil d'ariane
$racine_path = '../';  // Chemin de base pour les vues

/* Affichage de l'en-tête */
include($racine_path.'view/header.php');
echo '<main>'; 
require '../../class/Autoloader.php';
Autoloader::enregistrer();

use exception\OeuvreException; // Exception spécifique aux œuvres
use model\OeuvreModel; // Modèle pour les œuvres
use classes\Oeuvre; // Classe Oeuvre

$model = new OeuvreModel(); // Création d'une instance du modèle des œuvres

// Protection CSRF
if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
    throw new Exception("Erreur CSRF : requête invalide.");

}

// INSERT : Ajout d'une œuvre
if ($_POST['action'] === 'insert') {
    // Récupération des informations depuis le formulaire
    $titre = $_POST['titre'];
    $type = $_POST['type'];
    $date_creation = $_POST['date_creation'];
    $auteur = $_POST['auteur']; 
    $description = $_POST['description'];
    $imageName = null;

    // Traitement de l'image
    if (!empty($_FILES['image']['name'])) {
        $imageName = $_FILES['image']['name'];
        move_uploaded_file($_FILES['image']['tmp_name'], "../../images/" . $imageName);
    }
    // Création de l'objet œuvre
    $oeuvre = new Oeuvre(0, $titre, $type, $date_creation, $auteur, $description,$imageName);

    // Insertion de l'œuvre dans la base de données
    try {
        $model->insert($oeuvre);
        echo "Œuvre insérée : " . $oeuvre->titre;
    } catch (OeuvreException $e) {
        echo "Erreur : " . $e->getMessage();
    }
}

// UPDATE : Modification d'une œuvre existante
if ($_POST['action'] === 'update') {
    $id = $_POST['id'];
    $titre = $_POST['titre'];
    $type = $_POST['type'];
    $date_creation = $_POST['date_creation'];
    $auteur = $_POST['auteur']; // Nom de l'artiste
    $description = $_POST['description'];
    $imageName = null;

    // Traitement de l'image
    if (!empty($_FILES['image']['name'])) {
        $imageName = $id . "_" . $_FILES['image']['name'];
        move_uploaded_file($_FILES['image']['tmp_name'], "../../images/" . $imageName);
    }
    // Mise à jour de l'œuvre
    $oeuvre = new Oeuvre($id, $titre, $type, $date_creation, $auteur, $description, $imageName);

    // Mise à jour dans la base de données
    try {
        $model->update($oeuvre);
        echo "Œuvre modifiée : " . $oeuvre->titre;
    } catch (OeuvreException $e) {
        echo "Erreur : " . $e->getMessage();
    }
}

// DELETE : Suppression d'une œuvre
if ($_POST['action'] === 'delete') {
    $id = $_GET['id'];
    $choix = $_POST['choix'];

    // Suppression de l'œuvre si l'utilisateur a confirmé
    if ($choix === "oui") {
        $model->delete($id);
        echo "Œuvre supprimée";
    } else {
        echo "Suppression annulée";
    }
}

echo '</main>'; 

/* Affichage du footer */
include($racine_path.'view/footer.php');
?>