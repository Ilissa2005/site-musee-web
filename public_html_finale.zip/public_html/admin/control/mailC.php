<?php
/**
 * Contrôleur de la page contact.
 * 
 * Gère l'affichage du formulaire de contact et l'envoi d'un mail à un destinataire spécifié. 
 * Les informations de l'utilisateur (nom, prénom, email et message) sont récupérées à partir du formulaire soumis.
 * Le formulaire est sécurisé avec un token CSRF pour éviter les attaques.
 * Si toutes les données sont valides, le mail est envoyé à l'adresse spécifiée.
 *
 * @category Contrôleur
 * @package Musée
 * @author Ilissa Ingrachen, Afkir Hafsa
 * @version 1.0
 * 
 * @see view/header.php
 * @see view/contact.php
 * @see view/footer.php
 *
 * @param string $racine_path Chemin racine pour l'inclusion des fichiers (ex: header.php, contact.php, footer.php).
 * @param string $titre Titre de la page, ici "Contact - Musée Histoire des Œuvres".
 * @param string $pageariane Nom de la page dans la navigation, ici "Contact".
 * @param bool $envoye Indicateur pour savoir si le message a été envoyé avec succès.
 * @param string $erreur Message d'erreur si une erreur se produit lors de la soumission du formulaire.
 * @param string $nom Nom saisi par l'utilisateur.
 * @param string $prenom Prénom saisi par l'utilisateur.
 * @param string $email Email saisi par l'utilisateur.
 * @param string $message Message saisi par l'utilisateur.
 */
$racine_path = "../";

$titre = "Contact - Musée Histoire des Œuvres";
$pageariane = "Contact";
include($racine_path . "view/header.php");

$envoye = false;
$erreur = "";
$nom = "";
$prenom = "";  // Ajout de la variable pour le prénom
$email = "";
$message = "";

// Vérification de la méthode de requête (POST)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Vérification du token CSRF pour sécuriser le formulaire
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        throw new Exception("Erreur CSRF : requête invalide.");

    }

    // Traitement du formulaire si tous les champs sont remplis
    if (isset($_POST["nom"], $_POST["prenom"], $_POST["email"], $_POST["message"])) {  // Vérification du champ "prenom"
        $nom = trim($_POST["nom"]);
        $prenom = trim($_POST["prenom"]);  // Récupération du prénom
        $email = trim($_POST["email"]);
        $message = trim($_POST["message"]);

        // Validation des champs
        if ($nom == "" || $prenom == "" || $email == "" || $message == "") {  // Vérifier aussi si "prenom" est rempli
            $erreur = "Tous les champs sont obligatoires.";
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $erreur = "Adresse email invalide.";
        } else {

            
            $destinataire = "ingrachenilissa@gmail.com";  

            $sujet = "Message depuis le site Musée";

            $contenu = "Nom : " . $nom . "\n";
            $contenu .= "Prénom : " . $prenom . "\n";  // Inclure le prénom dans le corps du message
            $contenu .= "Email : " . $email . "\n\n";
            $contenu .= "Message :\n" . $message;

            // Utilisation de la fonction mail() pour envoyer l'email
            
            $headers = "From: " . $email . "\r\n";  // L'email de l'utilisateur comme expéditeur
            $headers .= "Reply-To: " . $email . "\r\n";  // Réponse envoyée à l'email de l'utilisateur
            $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";

            // Envoi de l'email
            $resultat = mail($destinataire, $sujet, $contenu, $headers);

            if ($resultat) {
                $envoye = true;

                // Réinitialisation des champs
                $nom = "";
                $prenom = "";  // Réinitialisation du prénom
                $email = "";
                $message = "";
            } else {
                $erreur = "La fonction mail() a échoué sur le serveur.";
            }
        }
    }
}

include($racine_path . "view/mailView.php");
include($racine_path . "view/footer.php");
?>