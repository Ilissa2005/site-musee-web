<?php
/**
 * Contrôleur de la page d'ajout.
 * Gère l'affichage des formulaires d'ajout en fonction du type d'objet sélectionné.
 *
 * Ce fichier permet d'ajouter des objets de différents types : œuvre, artiste ou utilisateur.
 * En fonction de la valeur du paramètre `type` passé dans l'URL, le contrôleur inclut le bon formulaire d'ajout (ajouter une œuvre, un artiste ou un utilisateur).
 * 
 * @category Controller
 * @package Musée
 * @author Ilissa Ingrachen, Afkir Hafsa
 * @version 1.0
 *
 * @throws Exception Si le type d'objet passé dans l'URL n'est pas reconnu.
 */
require_once '../../class/Autoloader.php';
Autoloader::enregistrer();
use model\ArtisteModel;

$racine_path = '../';  // Définition du chemin de base
$titre = "Ajouter";  // Titre de la page d'ajout

// Inclusion de l'en-tête de la page
include($racine_path."view/header.php");

echo '<main>';

// Récupération du type d'objet à ajouter depuis l'URL
$objet = $_GET["type"];

// Si l'objet est une œuvre, on récupère tous les artistes pour l'afficher dans le formulaire
if ($objet === "oeuvre") {
$artisteModel = new ArtisteModel();
$listeArtistes = $artisteModel->chercherAll(); // Récupération des artistes
    include($racine_path."view/ajouterOeuvreView.php");  // Inclusion du formulaire d'ajout d'œuvre
}
// Si l'objet est un artiste, on inclut le formulaire d'ajout d'artiste
elseif ($objet === "artiste") {
    include($racine_path."view/ajouterArtisteView.php");  // Inclusion du formulaire d'ajout d'artiste
}
// Si l'objet est un utilisateur, on inclut le formulaire d'ajout d'utilisateur
elseif ($objet === "user") {
    include($racine_path."view/ajouterUserView.php");  // Inclusion du formulaire d'ajout d'utilisateur
}
// Si le type d'objet est inconnu, on affiche un message d'erreur
else {
    echo "<h2>type inconnu</h2>";
}

echo '</main>';

// Inclusion du pied de page
include($racine_path."view/footer.php");

?>