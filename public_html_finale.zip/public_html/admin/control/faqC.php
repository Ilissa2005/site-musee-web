<?php
/**
 * Contrôleur de la page FAQ.
 * Gère l'affichage des questions fréquemment posées (FAQ) dans le musée.
 * Charge les questions et leurs réponses depuis un tableau.
 * Affiche chaque question et réponse dans un format structuré.
 * 
 * @category Controller
 * @package Musée
 * @author Ilissa Ingrachen, Afkir Hafsa
 * @version 1.0
 */

// Définition du chemin de base et des variables nécessaires
$racine_path = '../';
$titre = "FAQ - Musée Histoire des Œuvres";
$pageariane = "FAQ";

// Inclusion de l'entête de la page
include($racine_path."view/header.php");

echo '<main>';
echo "<header> Mon fil d'ariane -> vous êtes sur la page $pageariane </header>";

// Définition des questions et réponses
$faqs = array(
    array("qst1","REP"),
    array("qst2","rep2"),
    array("qst3","rep3")
);

// Affichage des questions et réponses
echo '<div class="cards-container">';
for ($i = 0; $i < count($faqs); $i++) {
    $id = $i;
    $qst = $faqs[$i][0];
    $rep = $faqs[$i][1];
    
    // Inclusion de la vue pour chaque question et réponse
    include($racine_path."view/faqV.php");
}
echo '</div>';
echo '</main>';

// Inclusion du pied de page
include($racine_path."view/footer.php");
?>