<?php
/**
 * Contrôleur de la page d'affichage des utilisateurs.
 * Ce fichier récupère et affiche la liste des utilisateurs dans le back-office.
 * Il permet également d'ajouter, modifier ou supprimer des utilisateurs.
 *
 * @category Controller
 * @package Musée
 * @author Ilissa Ingrachen, Afkir Hafsa
 * @version 1.0
 */

require_once '../../class/Autoloader.php';  // Inclusion de l'autoloader pour charger les classes
Autoloader::enregistrer();  // Enregistrement de l'autoloader
$racine_path = '../';  // Définition du chemin racine pour inclure les vues
$titre = "User - Musée Histoire des Œuvres";  // Titre de la page
$pageariane = 'User';  // Nom de la page dans le fil d'ariane

/* Header */
include($racine_path . "view/header.php");  // Inclusion de l'en-tête de la page
echo '<main>';  // Début du contenu principal
echo "<header> Mon fil d'ariane -> vous êtes sur la page $pageariane </header>";  // Fil d'ariane pour la navigation

// Récupération des utilisateurs depuis le modèle
use model\UtilisateurModel;
$model = new UtilisateurModel();
$users = $model->chercherAll();  // Récupère tous les utilisateurs

// Lien pour ajouter un nouvel utilisateur
echo '<a href="ajouter-0-user" class="btn btn-success";">Ajouter un user</a>';

// Conteneur des cartes d'utilisateurs
echo '<div class="cards-container">';

/* Boucle d'affichage des utilisateurs */
foreach ($users as $u) {
    // Récupération des données de chaque utilisateur
    $id = $u->id;
    $nom = $u->nom;
    $email = $u->email;
    $mdp = $u->mdp;
    $image=$u->image;
    // Liens pour modifier ou supprimer l'utilisateur
    $modifier = "modifier-" . $id . "-user";
    $sup = "sup-" . $id . "-user";
    
    // Inclusion de la vue pour afficher chaque utilisateur sous forme de carte
    include($racine_path . "view/user.php");
}

// Fermeture du conteneur et de la balise main
echo '</div>';
echo '</main>';  // Fin du contenu principal

/* Footer */
include($racine_path . "view/footer.php");  // Inclusion du pied de page
?>