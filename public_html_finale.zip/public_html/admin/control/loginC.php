<?php
/**
 * Contrôleur de connexion.
 * Ce fichier gère la connexion de l'utilisateur en vérifiant les informations de connexion
 * et en créant une session pour un utilisateur ayant un rôle d'administrateur.
 *
 * @category Controller
 * @package Musée
 * @author Ilissa Ingrachen, Afkir Hafsa
 * @version 1.0
 */

require_once '../../class/Autoloader.php';
Autoloader::enregistrer();

use model\UtilisateurModel;
session_start();

/**
 * Vérification de la validité du CSRF Token pour sécuriser le formulaire.
 */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        throw new Exception("Erreur CSRF : requête invalide.");

    }
}

/**
 * Initialisation des variables nécessaires à la connexion.
 */
$racine_path = '../';
$titre = "Connexion réussie";
$pageariane = "Connexion";
$email = $_POST['email'];
$mdp = $_POST['mdp'];

/**
 * Instanciation du modèle UtilisateurModel et vérification des informations de connexion.
 * Si l'email et le mot de passe sont corrects et que l'utilisateur est un administrateur,
 * une session est créée.
 */
$model = new UtilisateurModel();
$user = $model->verifierMotDePasse($email, $mdp);

echo '<main>';

if (!$user || $user->role != 'admin') {
    /**
     * Si l'utilisateur n'existe pas ou n'est pas un administrateur, une erreur est affichée
     * et le formulaire de connexion est renvoyé.
     */
    include($racine_path.'view/login.php');
    $message = "Email ou mot de passe incorrect";
    $r = "login";
    include($racine_path.'view/loginErrorView.php');
} else {
    /**
     * Si les informations sont valides, les données de l'utilisateur sont stockées dans la session
     * et une redirection est effectuée vers l'espace administrateur.
     */
    echo "hhhhh";
    $a = "accueilC";
    $_SESSION['id'] = $user->id;
    $_SESSION['email'] = $user->email;
    $_SESSION['nom'] = $user->nom;
    $_SESSION['role'] = $user->role;
    
    include($racine_path.'view/header.php');
    include($racine_path.'view/loginSuccessView.php');
}

echo '</main>';
?>