<?php
/**
 * Contrôleur de gestion des cookies.
 * Permet à l'utilisateur d'accepter, de refuser ou de personnaliser les cookies sur le site.
 * 
 * Ce fichier gère la création, la suppression et la modification des cookies concernant les préférences utilisateur.
 * Il vérifie également la validité du CSRF token pour sécuriser les actions.
 * 
 * @category Controller
 * @package Musée
 * @author Ilissa Ingrachen, Afkir Hafsa
 * @version 1.0
 */
// Démarrage de la session
session_start();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        throw new Exception("Erreur CSRF : requête invalide.");

    }
}
// Définir la durée de vie des cookies à 6 mois
$expire = time() + (180 * 24 * 60 * 60);  // 6 mois

// TOUT ACCEPTER : L'utilisateur accepte tous les cookies
if (isset($_GET['action']) && $_GET['action'] === 'accept') {
    setcookie("cookie_consent", "accept", $expire, "/");
    setcookie("cookie_stats", "1", $expire, "/");
    setcookie("cookie_perso", "1", $expire, "/");
    header("Location: ../accueilC");  // Redirection après acceptation
    exit();
}

// TOUT REFUSER : L'utilisateur refuse tous les cookies
if (isset($_GET['action']) && $_GET['action'] === 'refuse') {
    setcookie("cookie_consent", "reject", $expire, "/");
    setcookie("cookie_stats", "", time() - 3600, "/");
    setcookie("cookie_perso", "", time() - 3600, "/");
    header("Location: ../accueilC");  // Redirection après refus
    exit();
}

// ENREGISTRER LES PREFERENCES : L'utilisateur personnalise ses choix de cookies
if (isset($_GET['action']) && $_GET['action'] === 'save') {
    
    if (isset($_POST['stats'])) {
        setcookie("cookie_stats", "1", $expire, "/");
    } else {
        setcookie("cookie_stats", "", time() - 3600, "/");  // Suppression du cookie stats
    }
    if (isset($_POST['personalisation'])) {
        setcookie("cookie_perso", "1", $expire, "/");
    } else {
        setcookie("cookie_perso", "", time() - 3600, "/");  // Suppression du cookie perso
    }
    setcookie("cookie_consent", "custom", $expire, "/");  // Enregistrement des préférences personnalisées
    header("Location: ../accueilC");  // Redirection après sauvegarde
    exit();
}

?>