<?php
/**
 * Contrôleur des œuvres.
 * Gère l'affichage des œuvres dans le musée ainsi que les opérations associées (ajouter, modifier, supprimer).
 * Affiche la liste des œuvres existantes et permet d'ajouter une nouvelle œuvre.
 * 
 * @category Controller
 * @package Musée
 * @author Ilissa Ingrachen, Afkir Hafsa
 * @version 1.0
 */

// Définition du chemin racine pour inclure les vues et autres fichiers
$racine_path = '../';
$titre = "Oeuvre - Musée Histoire des Œuvres"; // Titre de la page
$pageariane = "Les Oeuvres";  // Nom de la page pour le fil d'ariane

/* Inclusion du header */
require_once "../../class/Autoloader.php";
Autoloader::enregistrer();  // Enregistre les classes nécessaires
use model\Artiste;  // Inclut la classe Artiste
use model\OeuvreModel;  // Inclut le modèle Oeuvre
include($racine_path . "view/header.php");  // Inclut le header de la page
use model\ArtisteModel;

// Vérifie si une erreur est présente dans l'URL et l'affiche
if (isset($_GET['error'])) {
    echo '<div class="alert alert-danger" style="margin: 20px;">Erreur : ' . $_GET['error'] . '</div>';
}

echo '<main>';  // Début du contenu principal de la page
echo "<header> Mon fil d'ariane -> vous êtes sur la page $pageariane </header>";  // Fil d'ariane

// Création d'une instance du modèle Oeuvre
$model = new OeuvreModel();
$oeuvres = $model->chercherAll();  // Récupère toutes les œuvres de la base de données

// Lien pour ajouter une nouvelle œuvre
echo '<a href="../admin/ajouter-0-oeuvre" class="btn btn-success" style="margin: 20px;">Ajouter une œuvre</a>';

// Conteneur des cartes des œuvres
echo '<div class="cards-container">';

// Boucle pour afficher chaque œuvre
foreach ($oeuvres as $oeuvre) {

    // Récupère les informations de chaque œuvre
    $id = $oeuvre->id;
    $nom_oeuvre = $oeuvre->titre;
    $type_o = $oeuvre->type;
    $description = $oeuvre->description;
    $annee = $oeuvre->date_creation;
    $artiste = $oeuvre->artiste;  // Nom de l'artiste
    $image = $oeuvre->image;
    // Liens pour modifier et supprimer une œuvre
    $modifier = $racine_path . 'admin/modifier-' . $id . '-oeuvre';
    $sup = $racine_path . 'admin/sup-' . $id . '-oeuvre';

    include($racine_path . "view/oeuvres.php");  // Affiche chaque œuvre dans la vue correspondante
}

echo '</div>';  // Fermeture du conteneur des cartes
echo '</main>';  // Fermeture du contenu principal

/* Inclusion du footer */
include($racine_path . "view/footer.php");  // Inclut le pied de page
?>