<?php
/**
 * Contrôleur de gestion des utilisateurs.
 * Permet l'ajout, la mise à jour et la suppression des utilisateurs via un formulaire.
 * 
 * @category Controller
 * @package Musée
 * @author Ilissa Ingrachen, Afkir Hafsa
 * @version 1.0
 */

// Inclusion du fichier Autoloader et initialisation de la session
$titre = "Accueil - Musée Histoire des Œuvres";
$pageariane = "Accueil"; 
$racine_path = '../';	
/*view*/  include($racine_path.'view/header.php');
echo '<main>'; 
require '../../class/Autoloader.php';
Autoloader::enregistrer();
use model\UtilisateurModel;
use classes\User;

// Vérification du token CSRF
$model = new UtilisateurModel();
if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
    throw new Exception("Erreur CSRF : requête invalide.");

}

// INSERT : Ajout d'un utilisateur
if ( $_POST['action'] === 'insert') {
    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $email = $_POST['email'];
    $mdp = password_hash($_POST['mdp'], PASSWORD_DEFAULT);
    $role = $_POST['role'];
    $imageName = null;

    // Gestion de l'upload de l'image
    if (!empty($_FILES['image']['name'])) {
        $imageName = $_FILES['image']['name'];
        move_uploaded_file($_FILES['image']['tmp_name'], "../../images/" . $imageName);
    }

    // Création et insertion de l'utilisateur
    $user = new User(0, $nom, $prenom, $email, $mdp, $role, $imageName);
    $model->insert($user);
    echo "Utilisateur inséré : " . $user->email;
}

// UPDATE : Mise à jour d'un utilisateur
if ($_POST['action'] === 'update') {
    $id = $_POST['id'];
    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $email = $_POST['email'];
    $mdp = $_POST['mdp'];
    $imageName = null;

    // Gestion de l'upload de l'image
    if (!empty($_FILES['image']['name'])) {
        $imageName = $_FILES['image']['name'];
        move_uploaded_file($_FILES['image']['tmp_name'], "../../images/" . $imageName);
    }

    // Récupérer l'utilisateur existant et mise à jour
    $users = $model->chercherAll();
    $user = null;
    foreach ($users as $u) {
        if ($u->id == $id) {
            $user = $u;
            break;
        }
    }

    // Vérification si l'utilisateur est trouvé
    if (!$user) {
        echo "Utilisateur introuvable";
    }

    // Mise à jour des informations de l'utilisateur
    $user->nom = $nom;
    $user->prenom = $prenom;
    $user->email = $email;
    if ($imageName) {
        $user->image = $imageName;
    }
    if (!empty($mdp)) {
        $user->mdp = password_hash($mdp, PASSWORD_DEFAULT);
    }
    $model->update($user);
    if($user->id==$_SESSION['id']){
        $_SESSION['id'] = $user->id;
        $_SESSION['email'] = $user->email;
        $_SESSION['nom'] = $user->nom;
    }
    echo "Utilisateur modifié : " . $user->email;
}

// DELETE : Suppression d'un utilisateur
if ($_POST['action'] === 'delete') {
    $id = $_GET['id'];
    $choix = $_POST['choix'];

    // Vérification de la suppression
    if ($choix === "oui") {
        $model->delete($id);
        echo "Utilisateur supprimé : " . $id;
    } else {
        echo "Suppression annulée";
    }
}

echo '</main>';
include($racine_path.'view/footer.php');
?>