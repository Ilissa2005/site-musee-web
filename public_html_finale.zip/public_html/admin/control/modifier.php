<?php
/**
 * Contrôleur de modification pour les objets du musée.
 * Permet de modifier les informations d'une oeuvre, d'un artiste ou d'un utilisateur.
 * Selon le type d'objet passé en paramètre, le fichier affiche un formulaire de modification.
 * 
 * @category Controller
 * @package Musée
 * @author Ilissa Ingrachen, Afkir Hafsa
 * @version 1.0
 */

// Inclus les classes nécessaires
require_once __DIR__ . '/../../class/Autoloader.php';
Autoloader::enregistrer();

$racine_path = '../';
$titre = "Modifier";  // Titre de la page
include($racine_path . "view/header.php");  // Inclut l'en-tête de la page

echo '<main>'; 

use model\ArtisteModel;
use model\UtilisateurModel;    
use model\OeuvreModel;

$id = $_GET["id"];  // Récupère l'ID de l'objet à modifier
$objet = $_GET["type"];  // Récupère le type d'objet (oeuvre, artiste, utilisateur)

// Gestion de la modification selon le type d'objet
if ($objet === "oeuvre") {
    // Si l'objet est une oeuvre
    $artisteModel = new ArtisteModel();
    $listeArtistes = $artisteModel->chercherAll();
    $model = new OeuvreModel();
    $oeuvre = $model->chercher($id);  // Recherche l'oeuvre par son ID
    $artisteModel = new ArtisteModel();
    $artistes = $artisteModel->chercherAll();  // Récupère tous les artistes pour l'affichage
    // Prépare les données de l'oeuvre
    $lien_image = "";
    $nom_oeuvre = $oeuvre->titre;
    $type = $oeuvre->type;
    $artiste = $oeuvre->auteur;
    $description = $oeuvre->description;
    $annee = $oeuvre->date_creation;

    include($racine_path . "view/modifierOeuvreView.php");  // Affiche le formulaire de modification de l'oeuvre
} elseif ($objet === "artiste") {
    // Si l'objet est un artiste
    $model = new ArtisteModel();
    $artiste = $model->chercher($id);  // Recherche l'artiste par son ID
    // Prépare les données de l'artiste
    $nom = $artiste->nom;
    $prenom = $artiste->prenom;
    $bio = $artiste->bio;

    include($racine_path . "view/modifierArtisteView.php");  // Affiche le formulaire de modification de l'artiste
} elseif ($objet === "user") {
    // Si l'objet est un utilisateur
    $model = new UtilisateurModel();
    $users = $model->chercherAll();  // Récupère tous les utilisateurs
    $user = null;
    // Recherche l'utilisateur par son ID
    foreach ($users as $u) {
        if ($u->id == $id) {
            $user = $u;
            break;
        }
    }

    if ($user === null) {
        echo "Utilisateur introuvable.";  // Affiche un message si l'utilisateur n'est pas trouvé
        exit;
    }

    include($racine_path . "view/modifierUserView.php");  // Affiche le formulaire de modification de l'utilisateur
}

echo '</main>'; 

include($racine_path . "view/footer.php");  // Inclut le pied de page
?>