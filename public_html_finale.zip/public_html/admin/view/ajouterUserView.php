<div class="form-box">
<form method="POST" action="gestion" enctype="multipart/form-data">
        <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
    <input type="hidden" name="id" value="<?php echo $id ?>">
    <input type="hidden" name="admin" value="<?php echo $id_admin ?>">
    <input type="hidden" name="type" value="user">
    <label> Role :</label>
    <input type="text" name="role" required>
    <label>Nom :</label>
    <input type="text" name="nom" required>
    <label>Prenom :</label>
    <input type="text" name="prenom" required>
    <label> Email :</label>
    <input type="text" name="email" required>
    <label>Password (l'utilisateur doit le changer):</label>
    <input type="password" name="mdp" required>
        <label>Image :</label>
    <input type="file" name="image">
    <button type="submit"name="action" value="insert">Ajouter</button>
</form>
</div>
