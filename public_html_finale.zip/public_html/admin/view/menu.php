
<nav class="navbar">
    <div class="container-fluid">
        <a class="navbar-brand" 
           href="<?= $racine_path.'admin/accueilC'?>">Accueil</a>
        <a class="navbar-brand" 
           href="<?= $racine_path.'admin/oeuvreControl' ?>">Oeuvres</a>
        <a class="navbar-brand" 
           href="<?= $racine_path.'admin/artisteControl' ?>">Artiste</a>
        <a class="navbar-brand" 
           href="<?= $racine_path.'admin/userControl'?>">Users</a>
        <a class="navbar-brand" 
           href="<?= $racine_path.'admin/adminControl'?>">Mon compte</a>
        <a class="navbar-brand" 
           href="<?= $racine_path.'admin/mailC' ?>">Envoyer un email</a>
        <a class="navbar-brand" 
           href="<?= $racine_path.'admin/faqC' ?>">FAQ</a>
        <a class="navbar-brand" 
           href="<?= $racine_path.'admin/deconexion' ?>">Déconnexion</a>
    </div>
</nav>