<div class="card" style="width: 18rem;">
  <img class="card-img-top" src="<?php echo "../images/" . $image; ?>">
  <div class="card-body">
    <h5 class="card-title"><?php echo $nom.' '.$prenom;?></h5>
    <p><strong>Email :</strong> <?php echo $email ?></p>
    <p><strong>Password :</strong> <?php echo $mdp ?></p>
    <a href="<?php echo $modifier;?>" class="btn btn-primary">Modifier</a>
  </div>
</div>
