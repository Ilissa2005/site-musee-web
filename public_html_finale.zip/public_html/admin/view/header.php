<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if(!isset($_SESSION['id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login");
    exit();
}
?>
<!DOCTYPE html>
<html>
	<head>
		<title> <?php echo $titre;?> de mon back Office </title>
		
		<!-- lien CDN pour un framework CSS -->
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
		<!-- insérer son propre CSS -->
		<link rel="stylesheet" href="<?php echo './view/css/styledef.css?v='.time(); ?>">
		
	</head>
	<body>
	<header>
		<h1> <?php echo $titre; ?> </h1>
		<?php include("menu.php"); ?>

	</header>
<?php
$consent = $_COOKIE['cookie_consent'] ?? null;
?>

<?php if (!$consent): ?>
<div style="background:#f5f5f5;padding:15px;border-top:1px solid #ccc;position:fixed;bottom:0;width:100%;z-index:9999;">
    <p class="mb-2">
        Ce site utilise des cookies pour améliorer votre expérience.
        Vous pouvez accepter, refuser ou personnaliser vos choix.
    </p>

    <a href="control/cookies.php?action=accept" class="btn btn-success btn-sm">Tout accepter</a>
    <a href="control/cookies.php?action=refuse" class="btn btn-danger btn-sm">Tout refuser</a>
    <button class="btn btn-secondary btn-sm"
            onclick="document.getElementById('cookie-modal').style.display='block';">
        Personnaliser
    </button>
</div>
<?php endif; ?>

<div id="cookie-modal"
     style="display:none;position:fixed;top:0;left:0;width:100%;height:100%;
            background:rgba(0,0,0,0.6);z-index:10000;">

    <div style="background:white;width:400px;margin:10% auto;padding:5px;border-radius:8px;">
        <h3>Préférences de cookies</h3>

        <form method="post" action="control/cookies.php?action=save">
            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
            <p>
                <input type="checkbox" checked disabled>
                Cookies nécessaires (toujours actifs)
				<details><p>Ces cookies sont indispensables au fonctionnement du site.(duree de vie :6 mois)</p></details>
            </p>

            <p>
                <input type="checkbox" name="stats">
                Cookies statistiques (mesure d’audience)
				<details><p>Ces cookies permettent de collecter des données anonymes sur la fréquentation du site.(duree de vie :6 mois)</p></details>
            </p>

            <p>
                <input type="checkbox" name="personalisation">
                Cookies de personnalisation (ex : type d’utilisateur)
				<details><p>Ces cookies permettent de personnaliser la couleur de menu.(duree de vie :6 mois)</p></details>
            </p>

            <button type="submit" class="btn btn-primary">Enregistrer mes choix</button>
            <button type="button" class="btn btn-secondary"
                    onclick="document.getElementById('cookie-modal').style.display='none';">
                Fermer
            </button>
        </form>
    </div>
</div>

