<div class="form-box">
<form method="POST" action="gestionArt" enctype="multipart/form-data">
    <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
    <input type="hidden" name="id" value="<?php echo $id ?>">
    <label>Nom:</label>
    <input type="text" name="nom" value="<?php echo $nom ?>" required>

    <label>Prenom :</label>
    <input type="text" name="prenom" value="<?php echo $prenom ?>" required>

    <label>Bio :</label>
    <input type="text" name="bio" value="<?php echo $bio ?>" required>
        <label>Image :</label>
    <input type="file" name="image">
    <button type="submit" name="action" value="update">Modifier</button>
</form>
</div>