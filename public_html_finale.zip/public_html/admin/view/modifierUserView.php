<div class="form-box">
<form method="POST" action="gestion" enctype="multipart/form-data">
    <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
    <input type="hidden" name="id" value="<?= $user->id ?>">
    <input type="hidden" name="type" value="user">

    <label>Nom:</label>
    <input type="text" name="nom" value="<?= $user->nom ?>" >

    <label>Prenom:</label>
    <input type="text" name="prenom" value="<?= $user->prenom ?>" >


    <label>Email :</label>
    <input type="text" name="email" value="<?= $user->email ?>" >

    <label>Nouveau mot de passe (optionnel) :</label>
    <input type="text" name="mdp" >
    <label>Image :</label>
    <input type="file" name="image">
    <button type="submit" name="action" value="update">Modifier</button>
</form>
</div>