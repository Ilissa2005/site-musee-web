<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="./view/css/style11.css">
    <title>Login Admin</title>
</head>
<body>
    <h1>Connexion Administrateur</h1>

<form method="POST" action="loginC">
    <label>Email :</label>
    <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
    <input type="email" name="email" required>

    <label>Mot de passe :</label>
    <input type="password" name="mdp" required>

    <button type="submit" name="login">Se connecter</button>
</form>
</body>
</html>
