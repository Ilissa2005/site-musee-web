<div class="error-box">
    <h2>Erreur de connexion</h2>
    <p><?= $message ?></p>
</div>
