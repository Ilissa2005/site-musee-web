<div class="form-box">
<form method="POST" action="gestionOeu" enctype="multipart/form-data">
    <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
    <input type="hidden" name="id" value="<?php echo $oeuvre->id ?>">

    <label>Titre :</label>
    <input type="text" name="titre" value="<?php echo $oeuvre->titre ?>" required>

    <label>Type :</label>
    <input type="text" name="type" value="<?php echo $oeuvre->type ?>" required>

  <label>Artiste :</label>
<select name="auteur" required>
    <option value="">-- Sélectionner un artiste --</option>

    <?php foreach ($listeArtistes as $artiste): ?>
        <option value="<?= $artiste->id ?>">
            <?= htmlspecialchars($artiste->prenom . " " . $artiste->nom) ?>
        </option>
    <?php endforeach; ?>
</select>
    <label>Description :</label>
    <input type="text" name="description" value="<?php echo $oeuvre->description ?>" required>

    <label>Date de création :</label>
    <input type="date" name="date_creation" value="<?php echo $oeuvre->date_creation ?>" required>
    <label>Image :</label>
    <input type="file" name="image">
    <button type="submit" name="action" value="update">Modifier</button>
</form>
</div>
