
<div class="success-box">
    <h2>Connexion réussie youpi!!</h2>
    <p>Bienvenue <strong><?= $_SESSION['nom'] ?></strong> !</p>
    <p>Vous êtes maintenant connecté en tant qu'administrateur.</p>
    <p>Vous pouvez accéder à votre tableau de bord pour gérer le site.</p>
    </div>
   <a href="<?= $a ?>" class="btn btn-primary">Accueil</a>
        Aller à l’accueil
    </a>

</div>
