<main class="container mt-4">
    <header>
        Vous êtes sur la page <?php echo $pageariane; ?>
    </header>

    <h2>Contact</h2>

    <?php if ($erreur != "") { ?>
        <div class="alert alert-danger mt-3"><?php echo htmlspecialchars($erreur); ?></div>
    <?php } ?>

    <?php if ($envoye) { ?>
        <div class="alert alert-success mt-3">Message envoyé avec succès.</div>
    <?php } ?>

    <div class="form-container">
        <form action="" method="POST">
            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">

            <label for="nom">Nom :</label>
            <input type="text" id="nom" name="nom" value="<?php echo htmlspecialchars($nom); ?>" required class="form-control mb-3">

            <label for="prenom">Prénom :</label>  <!-- Ajout du champ prénom -->
            <input type="text" id="prenom" name="prenom" value="<?php echo htmlspecialchars($prenom); ?>" required class="form-control mb-3">

            <label for="email">Email :</label>
            <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>" required class="form-control mb-3">

            <label for="message">Message :</label>
            <textarea id="message" name="message" rows="4" required class="form-control mb-3"><?php echo htmlspecialchars($message); ?></textarea>

            <input type="submit" value="Envoyer" class="btn btn-primary">
        </form>
    </div>
</main>