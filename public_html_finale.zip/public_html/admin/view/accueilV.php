<div class="accueil">
<h2>Bienvenue dans l’espace administrateur</h2>
<p>Depuis cet espace, vous pouvez gérer l’ensemble du contenu du site :</p>

<ul>
    <li>Ajouter, modifier ou supprimer des <strong>œuvres</strong></li>
    <li>Gérer les <strong>artistes</strong> et <strong>utilisateurs </strong></li>
    <li>Consulter et mettre à jour la <strong>FAQ</strong></li>
</ul>
<div>
    <p><strong>Nombre d’œuvres :</strong> <?php echo $nbOeuvres; ?></p>
    <p><strong>Nombre d’artistes :</strong> <?php echo $nbArtistes; ?></p>
    <p><strong>Nombre de visiteurs :</strong> <?php echo $nbr_visiteur; ?></p>
    <p><strong>Questions FAQ :</strong> 3</p>
</div>
</div>
