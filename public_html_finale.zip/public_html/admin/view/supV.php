<div class="form-box">
    <h2><?php echo $message;?></h2>
<form method="POST" action="<?php echo $revenir?>">
    <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
    <label> <input type="radio" name="choix" value="oui"> Oui </label> 
    <label> <input type="radio" name="choix" value="non"> Non </label>  
        <button type="submit" name="action" value="delete">Envoyer</button>
</form>
</div>