<?php
/**
 * Contrôleur de la page de connexion.
 * Ce fichier gère l'affichage de la page de connexion de l'utilisateur.
 * Il inclut la vue de connexion où l'utilisateur peut entrer ses informations d'identification.
 *
 * @category Controller
 * @package Musée
 * @author Ilissa Ingrachen, Afkir Hafsa
 * @version 1.0
 */

$titre = 'Login';  // Titre de la page
$racine_path = '';  // Chemin racine pour inclure les vues

$pageariane = 'Login';  // Nom de la page dans le fil d'ariane

/* View */
include($racine_path . 'view/login.php');  // Inclusion de la vue pour la page de connexion
?>