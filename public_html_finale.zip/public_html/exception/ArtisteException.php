<?php
namespace exception;

/**
 * Exception spécifique pour les erreurs liées aux artistes.
 * Étend `ModelException` et permet de définir un message et un code d'erreur personnalisés.
 *
 * @category Exception
 * @package Musée
 * @author Ilissa Ingrachen, Afkir Hafsa
 * @version 1.0
 * 
 * @param string $message Le message d'erreur (par défaut "Artiste non trouvé").
 * @param int $code Le code d'erreur (par défaut 404).
 */
use exception\ModelException;

class ArtisteException extends ModelException
{
    public function __construct($message = "Artiste non trouvé", $code = 404)
    {
        parent::__construct("erreur dans Artiste"."->".$message, $code);  // Appel du constructeur parent
    }
}
?>