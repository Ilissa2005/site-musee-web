<?php
namespace exception;

/**
 * Exception spécifique pour les erreurs de connexion à la base de données.
 * Étend `ModelException` et permet de personnaliser le message d'erreur et le code d'erreur.
 *
 * @category Exception
 * @package Musée
 * @author Ilissa Ingrachen, Afkir Hafsa
 * @version 1.0
 * 
 * @param string $message Le message d'erreur (par défaut "Erreur de connexion à la base de données").
 * @param int $code Le code d'erreur (par défaut 500).
 */
use exception\ModelException;

class ConnexionException extends ModelException
{
    public function __construct($message = "Erreur de connexion à la base de données", $code = 500)
    {
        parent::__construct($message, $code);
    }
}
?>