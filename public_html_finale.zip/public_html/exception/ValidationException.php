<?php
namespace exception;

use exception\ModelException;

/**
 * Exception levée pour les erreurs de validation des formulaires ou de saisie.
 * Cette exception est utilisée pour signaler que les données fournies sont invalides.
 * Elle étend `ModelException` et permet de personnaliser le message d'erreur et le code d'erreur.
 *
 * @category Exception
 * @package Musée
 * @author Ilissa Ingrachen, Afkir Hafsa
 * @version 1.0
 * 
 * @param string $message Le message d'erreur (par défaut "Données invalides").
 * @param int $code Le code d'erreur (par défaut 400).
 */
class ValidationException extends ModelException
{
    /**
     * Constructeur de l'exception ValidationException.
     * 
     * Permet de personnaliser le message d'erreur et le code d'erreur.
     * Par défaut, le message est "Données invalides" et le code est 400.
     * 
     * @param string $message Le message d'erreur détaillant la cause de l'exception.
     * @param int $code Le code d'erreur, par défaut 400.
     */
    public function __construct($message = "Données invalides", $code = 400)
    {
        parent::__construct($message, $code);
    }
}
?>