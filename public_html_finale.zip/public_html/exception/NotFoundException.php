<?php
namespace exception;

use exception\ModelException;

/**
 * Exception levée lorsqu'un élément recherché n'est pas trouvé.
 * Cette exception étend `ModelException` et est utilisée pour signaler que l'élément demandé n'existe pas.
 * Par défaut, cette exception renvoie un message "Élément non trouvé" avec un code d'erreur 404.
 *
 * @category Exception
 * @package Musée
 * @author Ilissa Ingrachen, Afkir Hafsa
 * @version 1.0
 * 
 * @param string $message Le message d'erreur (par défaut "Élément non trouvé").
 * @param int $code Le code d'erreur (par défaut 404).
 */
class NotFoundException extends ModelException
{
    /**
     * Constructeur de l'exception NotFoundException.
     * 
     * Permet de personnaliser le message d'erreur et le code d'erreur.
     * 
     * @param string $message Le message d'erreur détaillant l'élément introuvable.
     * @param int $code Le code d'erreur, par défaut 404.
     */
    public function __construct($message = "Élément non trouvé", $code = 404)
    {
        parent::__construct($message, $code);
    }
}
?>