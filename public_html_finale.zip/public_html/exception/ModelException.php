<?php
namespace exception;

use exception\ModelException;

/**
 * Exception générale pour les erreurs dans le modèle.
 * Cette classe étend la classe native `Exception` pour personnaliser les messages d'erreur et les codes.
 * Elle est utilisée pour signaler des erreurs génériques liées à la logique métier ou aux opérations dans le modèle.
 *
 * @category Exception
 * @package Musée
 * @author Ilissa Ingrachen, Afkir Hafsa
 * @version 1.0
 * 
 * @param string $message Le message d'erreur (par défaut "Erreur du modèle").
 * @param int $code Le code d'erreur (par défaut 500).
 */
class ModelException extends \Exception
{
    /**
     * Constructeur de l'exception.
     * 
     * Permet de personnaliser le message d'erreur et le code d'erreur.
     * 
     * @param string $message Le message d'erreur détaillé.
     * @param int $code Le code d'erreur.
     */
    public function __construct($message = "Erreur du modèle", $code = 500)
    {
        parent::__construct("Erreur dans modèle"."->".$message, $code);
    }
}
?>