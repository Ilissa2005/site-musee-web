<?php
namespace exception;

use exception\ModelException;

/**
 * Exception spécifique pour les erreurs liées aux utilisateurs.
 * Cette exception est levée lorsqu'il y a une erreur lors de la gestion des utilisateurs.
 * Elle étend `ModelException` et permet de personnaliser le message d'erreur et le code d'erreur.
 *
 * @category Exception
 * @package Musée
 * @author Ilissa Ingrachen, Afkir Hafsa
 * @version 1.0
 * 
 * @param string $message Le message d'erreur (par défaut "Utilisateur non trouvé").
 * @param int $code Le code d'erreur (par défaut 404).
 */
class UtilisateurException extends ModelException
{
    /**
     * Constructeur de l'exception UtilisateurException.
     * 
     * Permet de personnaliser le message d'erreur et le code d'erreur.
     * Par défaut, le message est "Utilisateur non trouvé" et le code est 404.
     * 
     * @param string $message Le message d'erreur détaillant l'erreur liée à l'utilisateur.
     * @param int $code Le code d'erreur, par défaut 404.
     */
    public function __construct($message = "Utilisateur non trouvé", $code = 404)
    {
        parent::__construct("Erreur dans Utilisateur"."->".$message, $code);
    }
}
?>