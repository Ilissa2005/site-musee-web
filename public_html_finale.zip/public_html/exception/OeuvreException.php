<?php
namespace exception;

use exception\ModelException;

/**
 * Exception spécifique pour les erreurs liées aux œuvres.
 * Cette exception est levée lorsque des erreurs se produisent dans le cadre de la gestion des œuvres.
 * Elle étend `ModelException` et permet de personnaliser le message d'erreur et le code d'erreur.
 *
 * @category Exception
 * @package Musée
 * @author Ilissa Ingrachen, Afkir Hafsa
 * @version 1.0
 * 
 * @param string $message Le message d'erreur (par défaut "Oeuvre non trouvée").
 * @param int $code Le code d'erreur (par défaut 404).
 */
class OeuvreException extends ModelException
{
    /**
     * Constructeur de l'exception OeuvreException.
     * 
     * Permet de personnaliser le message d'erreur et le code d'erreur.
     * Par défaut, le message est "Oeuvre non trouvée" et le code est 404.
     * 
     * @param string $message Le message d'erreur détaillant l'erreur liée à l'œuvre.
     * @param int $code Le code d'erreur, par défaut 404.
     */
    public function __construct($message = "Oeuvre non trouvée", $code = 404)
    {
        parent::__construct("Erreur dans Oeuvre"."->".$message, $code);
    }
}
?>