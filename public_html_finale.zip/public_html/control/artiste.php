<?php
/**
 * Contrôleur pour la page des artistes du musée.
 * Récupère et affiche les artistes depuis la base de données.
 * 
 * @category Controleur
 * @package Musée
 * @author Ilissa Ingrachen, Afkir Hafsa
 * @version 1.0
 * @see ArtisteModel
 * 
 * @param string $racine_path Chemin racine pour l'inclusion des fichiers.
 * @param string $titre Titre de la page.
 * @param string $pageariane Nom de la page dans la navigation.
 * @param string $nom_artiste Nom de l'artiste.
 * @param string $description_artiste Description de l'artiste.
 * @param string $lien_image_artiste Lien vers l'image de l'artiste.
 * @param string $lien_fiche_artiste Lien vers la fiche détaillée de l'artiste.
 */

// Chemin racine pour l'inclusion des fichiers
$racine_path = "../";  

// Titre et page actuelle pour l'affichage dans l'en-tête
$titre = "Artistes - Musée Histoire des Œuvres";
$pageariane = "Artistes";  

// Chargement de l'autoloader pour la gestion des classes
require_once __DIR__ . "/../class/Autoloader.php";
Autoloader::enregistrer(); // Enregistrement de l'autoloader

// Utilisation du modèle ArtisteModel pour récupérer les artistes
use model\ArtisteModel;

// Création d'une instance du modèle
$model = new ArtisteModel();

// Inclusion du header de la page
include($racine_path."view/header.php");

echo "<main>";
echo "<header> Vous êtes sur la page ".$pageariane." </header>";  // Affichage du titre de la page

echo "<div class='container'>";
echo "<div class='row'>";

// Bloc try-catch pour gérer les erreurs lors de la récupération des artistes
try {
    // Appel du modèle pour récupérer tous les artistes
    $artistes = $model->chercherAll();

    // Parcours et affichage des artistes
    foreach ($artistes as $a) {
        // Récupération des informations de chaque artiste
        $id = $a->id;
        $prenom_artiste = $a->prenom;
        $nom_artiste = $a->nom;
        $description_artiste = $a->description;

        // Construction des liens pour l'image et la fiche de l'artiste
        $lien_image_artiste = "images/" . $a->image;
        $lien_fiche_artiste = "artiste-" . $id;

        // Inclusion de la vue pour afficher chaque artiste
        include($racine_path . "view/artiste.php");
    }
} catch (Exception $e) {
    // En cas d'erreur, affiche un message d'alerte
    echo "<div class='alert alert-danger'>".$e->getMessage()."</div>";
}

echo "</div>";
echo "</div>"; 
echo "</main>";

// Inclusion du footer de la page
include($racine_path."view/footer.php");
?>