<?php
/**
 * Contrôleur pour la page de confirmation de contact.
 * Affiche un message de remerciement après l'envoi d'un message de contact.
 *
 * @category Controleur
 * @package Musée
 * @author Ilissa Ingrachen, Afkir Hafsa
 * @version 1.0
 * @see header.php, footer.php
 * 
 * @param string $racine_path Chemin racine pour l'inclusion des fichiers.
 * @param string $titre Titre de la page.
 */

// Définir le chemin racine pour l'inclusion des fichiers
$racine_path = "../";  

// Définir le titre de la page
$titre = "Merci d'avoir pris contact avec nous";  

// Inclusion du header de la page
include($racine_path."view/header.php");

// Affichage du message de remerciement
echo "<p>Nous vous répondrons dans les plus brefs délais.</p>";  

// Inclusion du footer de la page
include($racine_path."view/footer.php");
?>