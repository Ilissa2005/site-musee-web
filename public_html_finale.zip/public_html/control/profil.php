<?php
/**
 * Contrôleur pour la page de profil de l'utilisateur.
 * Permet d'afficher les informations du profil d'un utilisateur connecté.
 * Si l'utilisateur n'est pas connecté, il est redirigé vers la page de connexion.
 *
 * @category Controleur
 * @package Musée
 * @author Ilissa Ingrachen, Afkir Hafsa
 * @version 1.0
 * @see UtilisateurModel
 * 
 * @param string $racine_path Chemin racine pour l'inclusion des fichiers.
 * @param string $titre Titre de la page.
 * @param string $pageariane Nom de la page dans la navigation.
 * @param string $erreur Message d'erreur en cas d'exception.
 * @param string $nom Nom de l'utilisateur.
 * @param string $prenom Prénom de l'utilisateur.
 * @param string $mail Email de l'utilisateur.
 * @param string $role Rôle de l'utilisateur (admin, user).
 * @param string $lien_modifier Lien vers la page de modification du profil.
 * @param string $lien_supprimer Lien vers la page de suppression du profil.
 */

// Démarre la session et initialise le chemin racine
session_start();
$racine_path = "../";  

// Titre de la page et nom dans la navigation
$titre = "Profil - Musée Histoire des Œuvres";
$pageariane = "Profil";  

// Chargement de l'autoloader et du modèle
require_once __DIR__ . "/../class/Autoloader.php";
Autoloader::enregistrer();  // Enregistrement de l'autoloader
use model\UtilisateurModel;  // Utilisation du modèle pour l'utilisateur

// Vérification si l'utilisateur est connecté, sinon redirection vers la page de connexion
if (!isset($_SESSION["user"])) {
    header("Location: connexion");
    exit();
}

// Initialisation des variables pour afficher les informations utilisateur
$erreur = "";
$nom = "";
$prenom = "";
$mail = "";
$role = "";
$lien_modifier = "";
$lien_supprimer = "";

// Bloc try-catch pour récupérer les informations de l'utilisateur
try {
    // Récupération des informations de l'utilisateur connecté
    $id_user = $_SESSION["user"]["id"];
    $model = new UtilisateurModel();
    $u = $model->chercherParId($id_user);  // Récupération de l'utilisateur par ID

    // Assignation des informations utilisateur
    $nom = $u->nom;
    $prenom = $u->prenom;
    $mail = $u->email;
    $role = $u->role;

    // Création des liens pour modifier ou supprimer le profil
    $lien_modifier = "modifier" ;
    $lien_supprimer = "supprimer";
} catch (Exception $e) {
    // En cas d'erreur, affiche le message d'erreur
    $erreur = $e->getMessage();
}

// Inclusion de la vue du profil utilisateur
include($racine_path . "view/profil.php");
?>