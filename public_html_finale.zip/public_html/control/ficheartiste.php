<?php
/**
 * Contrôleur pour la page de fiche artiste.
 * Affiche les informations détaillées d'un artiste, telles que sa biographie et son image.
 * En cas d'erreur (identifiant invalide ou artiste non trouvé), affiche un message d'erreur.
 *
 * @category Controleur
 * @package Musée
 * @author Ilissa Ingrachen, Afkir Hafsa
 * @version 1.0
 * @see ArtisteModel
 * @see header.php, footer.php
 * 
 * @param string $racine_path Chemin racine pour l'inclusion des fichiers.
 * @param string $titre Titre de la page.
 * @param string $pageariane Nom de la page dans la navigation.
 * @param string $erreur Message d'erreur s'il y en a.
 * @param string $id Identifiant de l'artiste passé via l'URL.
 * @param object $artiste Objet contenant les informations de l'artiste.
 * @param string $lien_image_artiste Lien vers l'image de l'artiste.
 */

// Chemin racine pour l'inclusion des fichiers
$racine_path = "../";  

// Titre de la page et nom dans la navigation
$titre = "Fiche artiste - Musée Histoire des Œuvres";  
$pageariane = "Fiche artiste";  

// Chargement de l'autoloader et du modèle ArtisteModel
require_once __DIR__ . "/../class/Autoloader.php";
Autoloader::enregistrer();  // Enregistrement de l'autoloader
use model\ArtisteModel;  // Utilisation du modèle pour l'artiste

// Initialisation de la variable d'erreur
$erreur = "";

try {
    // Récupération de l'identifiant de l'artiste depuis l'URL
    $id = isset($_GET["id"]) ? (int)$_GET["id"] : 0;

    // Vérification de l'existence de l'artiste
    if ($id <= 0) {
        throw new Exception("Identifiant invalide");  // Si l'identifiant est invalide
    }

    // Création du modèle ArtisteModel et récupération de l'artiste
    $model = new ArtisteModel();
    $artiste = $model->chercher($id);  // Récupère les informations de l'artiste par ID

    // Lien de l'image de l'artiste
    $lien_image_artiste = "images/" . $artiste->image;
} catch (Exception $e) {
    // En cas d'exception, affiche le message d'erreur
    $erreur = $e->getMessage();
}

// Inclusion du header
include($racine_path . "view/header.php");
?>

<main class="container mt-4">

    <header>
        Vous êtes sur la page <?php echo $pageariane; ?>
    </header>

    <?php if ($erreur != "") { ?>
        <!-- Affichage du message d'erreur si l'artiste n'est pas trouvé -->
        <div class="alert alert-danger"><?php echo $erreur; ?></div>
    <?php } else { ?>
        <div class="row mt-4">
            <!-- Affichage de l'image de l'artiste -->
            <div class="col-md-5">
                <img src="<?php echo $lien_image_artiste; ?>" class="img-fluid">
            </div>

            <!-- Affichage des informations sur l'artiste -->
            <div class="col-md-7">
                <h2><?php echo $artiste->prenom . " " . $artiste->nom; ?></h2>
                <p><?php echo $artiste->bio; ?></p>
            </div>
        </div>
    <?php } ?>

</main>

<?php 
// Inclusion du footer
include($racine_path . "view/footer.php"); 
?>