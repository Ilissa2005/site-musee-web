<?php
/**
 * Contrôleur pour la page "Plan du site".
 * Affiche le plan du site avec les liens vers les différentes sections du site.
 *
 * @category Controleur
 * @package Musée
 * @author Ilissa Ingrachen, Afkir Hafsa
 * @version 1.0
 * @see view/plan_du_site.php
 * 
 * @param string $racine_path Chemin racine pour l'inclusion des fichiers.
 * @param string $titre Titre de la page.
 * @param string $pageariane Nom de la page dans la navigation.
 */

// Chemin racine pour l'inclusion des fichiers
$racine_path = "../";  

// Titre de la page et nom dans la navigation
$titre = "Plan du site";  
$pageariane = "Plan du site";  

// Inclusion du header de la page
include($racine_path . "view/header.php");
?>

<main>
    <h1>Plan du site</h1>

    <ul>
        <li><a href="accueil">Accueil</a></li>
        <li><a href="oeuvre">Œuvres</a></li>
        <li><a href="oeuvre/1">Œuvre 1</a></li>
        <li><a href="oeuvre/2">Œuvre 2</a></li>
        <li><a href="artiste">Artistes</a></li>
        <li><a href="artiste/1">Artiste 1</a></li>
        <li><a href="artiste/2">Artiste 2</a></li>
        <li><a href="contact">Contact</a></li>
        <li><a href="connexion">Connexion</a></li>
        <li><a href="profil">Profil</a></li>
        <li><a href="mentions">Mentions légales</a></li>
    </ul>
</main>

<?php
// Inclusion du footer de la page
include($racine_path . "view/footer.php");
?>