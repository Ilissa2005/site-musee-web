<?php
/**
 * Contrôleur pour la page de suppression de compte utilisateur.
 * Permet à l'utilisateur connecté de supprimer son compte après confirmation.
 *
 * @category Controleur
 * @package Musée
 * @author Ilissa Ingrachen, Afkir Hafsa
 * @version 1.0
 * @see UtilisateurModel
 * 
 * @param string $racine_path Chemin racine pour l'inclusion des fichiers.
 * @param string $titre Titre de la page.
 * @param string $pageariane Nom de la page dans la navigation.
 * @param string $erreur Message d'erreur si la suppression échoue.
 * @param string $mdp Mot de passe de l'utilisateur pour confirmer la suppression.
 * @param string $confirmation Confirmation de la suppression (doit être "oui").
 * @param int $id_user ID de l'utilisateur à supprimer.
 */

// Démarre la session pour l'utilisation des variables de session
session_start();

// Définition du chemin racine pour l'inclusion des fichiers
$racine_path = "../";

// Titre de la page et nom dans la navigation
$titre = "Supprimer compte - Musée Histoire des Œuvres";
$pageariane = "Supprimer";

// Chargement de l'autoloader et du modèle UtilisateurModel
require_once __DIR__ . "/../class/Autoloader.php";
Autoloader::enregistrer();  // Enregistrement de l'autoloader
use model\UtilisateurModel;

// Initialisation de la variable d'erreur
$erreur = "";

// Vérification si l'utilisateur est connecté, sinon redirection vers la page de connexion
if (!isset($_SESSION["user"])) {
    header("Location: connexion");
    exit();
}



try {
    // Récupération de l'ID de l'utilisateur connecté
    $id_user = (int)$_SESSION["user"]["id"];

    // Création d'une instance du modèle UtilisateurModel
    $utilisateurModel = new UtilisateurModel();
    $utilisateur = $utilisateurModel->chercherParId($id_user);  // Récupération des informations de l'utilisateur

    // Traitement du formulaire de suppression
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $mdp = isset($_POST["mdp"]) ? trim($_POST["mdp"]) : "";
        $confirmation = isset($_POST["confirmation"]) ? $_POST["confirmation"] : "";

        // Vérification si tous les champs sont remplis
        if ($mdp == "") {
            throw new Exception("Veuillez saisir votre mot de passe.");
        }

        if ($confirmation != "oui") {
            throw new Exception("Veuillez confirmer la suppression.");
        }

        // Vérification du mot de passe de l'utilisateur
        if ($mdp != $utilisateur->mdp && !password_verify($mdp, $utilisateur->mdp)) {
            throw new Exception("Mot de passe incorrect.");
        }

        // Suppression du compte utilisateur
        $utilisateurModel->delete($id_user);

        // Suppression des informations de la session et déconnexion de l'utilisateur
        $_SESSION = [];
        session_destroy();

        // Redirection vers la page d'accueil après suppression
        header("Location: accueil");
        exit();
    }
}
catch (Exception $e) {
    // En cas d'erreur, le message d'erreur est affiché
    $erreur = $e->getMessage();
}

// Inclusion de la vue de suppression de compte
include($racine_path . "view/supprimer.php");
?>