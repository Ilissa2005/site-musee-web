<?php
/**
 * Contrôleur pour la gestion des cookies.
 * Permet à l'utilisateur d'accepter, refuser ou personnaliser ses préférences de cookies.
 * 
 * @category Controleur
 * @package Musée
 * @author Ilissa Ingrachen, Afkir Hafsa
 * @version 1.0
 * @see ../index.php
 * 
 * @param string $expire Date d'expiration des cookies (180 jours).
 * @param string $csrf_token Token CSRF pour vérifier la requête.
 * @param string $cookie_consent Consentement de l'utilisateur.
 * @param string $cookie_stats Cookies statistiques.
 * @param string $cookie_perso Cookies de personnalisation.
 */

// Démarre la session pour l'utilisation des variables de session
session_start();

// Définir la date d'expiration des cookies (180 jours)
$expire = time() + (180 * 24 * 60 * 60);  // 6 mois

// Vérification du token CSRF pour sécuriser les requêtes
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        throw new Exception("Erreur CSRF : requête invalide.");

    }
}

// Gérer l'acceptation des cookies (tout accepter)
if (isset($_GET['action']) && $_GET['action'] === 'accept') {
    setcookie("cookie_consent", "accept", $expire, "/");
    setcookie("cookie_stats", "1", $expire, "/");
    setcookie("cookie_perso", "1", $expire, "/");
    header("Location: ../index.php");
    exit();
}

// Gérer le refus des cookies (tout refuser)
if (isset($_GET['action']) && $_GET['action'] === 'refuse') {
    setcookie("cookie_consent", "reject", $expire, "/");
    setcookie("cookie_stats", "", time() - 3600, "/");
    setcookie("cookie_perso", "", time() - 3600, "/");
    header("Location: ../index.php");
    exit();
}

// Gérer l'enregistrement des préférences de cookies
if (isset($_GET['action']) && $_GET['action'] === 'save') {
    // Gestion des cookies statistiques
    if (isset($_POST['stats'])) {
        setcookie("cookie_stats", "1", $expire, "/");
    } else {
        setcookie("cookie_stats", "", time() - 3600, "/");  // Supprimer
    }
    // Gestion des cookies de personnalisation
    if (isset($_POST['personalisation'])) {
        setcookie("cookie_perso", "1", $expire, "/");
    } else {
        setcookie("cookie_perso", "", time() - 3600, "/");  // Supprimer
    }
    // Enregistrer le consentement de l'utilisateur
    setcookie("cookie_consent", "custom", $expire, "/");
    header("Location: ../index.php");
    exit();
}
?>