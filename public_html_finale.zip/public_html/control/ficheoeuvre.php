<?php
/**
 * Contrôleur pour la page de fiche œuvre.
 * Affiche les informations détaillées d'une œuvre, telles que son titre, son type, sa date de création, et son artiste.
 * En cas d'erreur (identifiant invalide ou œuvre non trouvée), affiche un message d'erreur.
 *
 * @category Controleur
 * @package Musée
 * @author Ilissa Ingrachen, Afkir Hafsa
 * @version 1.0
 * @see OeuvreModel
 * @see header.php, footer.php
 * 
 * @param string $racine_path Chemin racine pour l'inclusion des fichiers.
 * @param string $titre Titre de la page.
 * @param string $pageariane Nom de la page dans la navigation.
 * @param string $erreur Message d'erreur s'il y en a.
 * @param string $id Identifiant de l'œuvre passé via l'URL.
 * @param object $oeuvre Objet contenant les informations de l'œuvre.
 * @param string $lien_image_oeuvre Lien vers l'image de l'œuvre.
 */

// Chemin racine pour l'inclusion des fichiers
$racine_path = "../";  

// Titre de la page et nom dans la navigation
$titre = "Fiche œuvre - Musée Histoire des Œuvres";  
$pageariane = "Fiche œuvre";  

// Chargement de l'autoloader et du modèle OeuvreModel
require_once __DIR__ . "/../class/Autoloader.php";
Autoloader::enregistrer();  // Enregistrement de l'autoloader
use model\OeuvreModel;  // Utilisation du modèle pour l'œuvre

// Initialisation de la variable d'erreur
$erreur = "";

try {
    // Récupération de l'identifiant de l'œuvre depuis l'URL
    $id = isset($_GET["id"]) ? (int)$_GET["id"] : 0;

    // Vérification de l'existence de l'œuvre
    if ($id <= 0) {
        throw new Exception("Identifiant invalide");  // Si l'identifiant est invalide
    }

    // Création du modèle OeuvreModel et récupération de l'œuvre
    $model = new OeuvreModel();
    $oeuvre = $model->chercher($id);  // Récupère les informations de l'œuvre par ID

    // Lien de l'image de l'œuvre
    $lien_image_oeuvre = "images/" . $oeuvre->image;
} catch (Exception $e) {
    // En cas d'exception, affiche le message d'erreur
    $erreur = $e->getMessage();
}

// Inclusion du header
include($racine_path . "view/header.php");
?>

<main class="container mt-4">

    <header>
        Vous êtes sur la page <?php echo $pageariane; ?>
    </header>

    <?php if ($erreur != "") { ?>
        <!-- Affichage du message d'erreur si l'œuvre n'est pas trouvée -->
        <div class="alert alert-danger"><?php echo $erreur; ?></div>
    <?php } else { ?>
        <div class="row mt-4">
            <!-- Affichage de l'image de l'œuvre -->
            <div class="col-md-5">
                <img src="<?php echo $lien_image_oeuvre; ?>" class="img-fluid">
            </div>

            <!-- Affichage des informations sur l'œuvre -->
            <div class="col-md-7">
                <h2><?php echo $oeuvre->titre; ?></h2>
                <p><strong>Type :</strong> <?php echo $oeuvre->type; ?></p>
                <p><strong>Date de création :</strong> <?php echo $oeuvre->date_creation; ?></p>
                <p><strong>Artiste :</strong> <?php echo $oeuvre->auteur->prenom . ' ' . $oeuvre->auteur->nom; ?></p>

                <p><?php echo $oeuvre->description; ?></p>
            </div>
        </div>
    <?php } ?>

</main>

<?php 
// Inclusion du footer
include($racine_path . "view/footer.php"); 
?>