<?php
/**
 * Contrôleur pour la page des réglementations.
 * Gère l'affichage des réglementations et inclut les fichiers nécessaires à l'affichage.
 *
 * @category Controleur
 * @package Musée
 * @author Ilissa Ingrachen, Afkir Hafsa
 * @version 1.0
 * @see mentions.php, footer.php
 * 
 * @param string $racine_path Chemin racine pour l'inclusion des fichiers.
 * @param string $titre Titre de la page.
 * @param string $pageariane Nom de la page dans la navigation.
 */

// Définir le chemin racine pour l'inclusion des fichiers
$racine_path = "../";  

// Définir le titre de la page et le nom de la page dans la navigation
$titre = "Réglementations - Musée Histoire des Œuvres";  
$pageariane = "Réglementations";  

// Inclusion du header de la page
include($racine_path . "view/header.php");

// Inclusion du fichier des réglementations
include($racine_path . "view/mentions.php");

// Inclusion du footer de la page
include($racine_path . "view/footer.php");
?>