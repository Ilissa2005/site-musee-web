<?php
/**
 * Contrôleur pour la page de déconnexion.
 * Permet à l'utilisateur de se déconnecter après avoir saisi son mot de passe.
 * Si le mot de passe est correct, l'utilisateur est déconnecté et redirigé vers la page d'accueil.
 *
 * @category Controleur
 * @package Musée
 * @author Ilissa Ingrachen, Afkir Hafsa
 * @version 1.0
 * @see UtilisateurModel
 * @see header.php, deconnexion.php, footer.php
 * 
 * @param string $racine_path Chemin racine pour l'inclusion des fichiers.
 * @param string $titre Titre de la page.
 * @param string $pageariane Nom de la page dans la navigation.
 * @param string $erreur Message d'erreur si le mot de passe est incorrect.
 * @param string $mdp Mot de passe saisi par l'utilisateur pour la déconnexion.
 * @param string $email Email de l'utilisateur stocké en session.
 * @param string $url_path Chemin de l'URL de redirection après déconnexion.
 */

// Démarre la session et initialise les variables nécessaires
session_start();

// Chemin racine pour l'inclusion des fichiers
$racine_path = "../";  

// Titre de la page et nom dans la navigation
$titre = "Déconnexion - Musée Histoire des Œuvres";  
$pageariane = "Déconnexion";  

// Chargement de l'autoloader et du modèle UtilisateurModel
require_once __DIR__ . "/../class/Autoloader.php";
Autoloader::enregistrer();  // Enregistrement de l'autoloader
use model\UtilisateurModel;  // Utilisation du modèle pour l'utilisateur

// Initialisation des variables d'erreur et de mot de passe
$erreur = "";

if ($_SERVER["REQUEST_METHOD"] == "POST"  ) {
    // Récupération du mot de passe saisi
        if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        throw new Exception("Erreur CSRF : requête invalide.");

    }
    $mdp = isset($_POST["mdp"]) ? $_POST["mdp"] : "";

    // Vérification si le mot de passe a été saisi
    if (empty($mdp)) {
        $erreur = "Veuillez entrer votre mot de passe.";  // Message d'erreur si vide
    } else {
        // Récupération de l'email de l'utilisateur connecté
        $email = $_SESSION["user"]['email'];  

        // Création du modèle UtilisateurModel
        $model = new UtilisateurModel();

        // Vérification du mot de passe avec la fonction de connexion
        $user = $model->verifierMotDePasseFront($email, $mdp);

        // Si le mot de passe est correct, procéder à la déconnexion
        if ($user) {
            setcookie("cookie_consent", "", time() - 3600, "/");
            session_unset();  // Effacer toutes les variables de session
            session_destroy();  // Détruire la session active

            // Redirection vers la page d'accueil après déconnexion
            header("Location: accueil");
            exit();
        } else {
            // Si le mot de passe est incorrect, afficher un message d'erreur
            $erreur = "Mot de passe incorrect.";
        }
    }
}
// Vérification si l'utilisateur est connecté, sinon redirection vers la page de connexion
if (!isset($_SESSION["user"])) {
    header("Location: connexion");
    exit();
}
// Inclusion des vues de la page de déconnexion
include($racine_path . "view/header.php");
include($racine_path . "view/deconnexion.php");
include($racine_path . "view/footer.php");
?>