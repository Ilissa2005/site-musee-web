<?php
/**
 * Contrôleur de connexion.
 * Gère la connexion de l'utilisateur, la vérification du mot de passe,
 * et la redirection vers le profil après une connexion réussie.
 *
 * @category Controleur
 * @package Musée
 * @author Ilissa Ingrachen, Afkir Hafsa
 * @version 1.0
 * @see UtilisateurModel
 * 
 * @param string $racine_path Chemin racine pour l'inclusion des fichiers.
 * @param string $titre Titre de la page.
 * @param string $pageariane Nom de la page dans la navigation.
 * @param string $erreur Message d'erreur en cas de connexion échouée.
 * @param string $email Adresse email saisie par l'utilisateur.
 * @param string $mdp Mot de passe saisi par l'utilisateur.
 */

// Démarre la session pour l'utilisation des variables de session
session_start();

// Chemin racine pour l'inclusion des fichiers
$racine_path = "../";  

// Titre de la page et nom dans la navigation
$titre = "Connexion - Musée Histoire des Œuvres";
$pageariane = "Connexion";  

// Chargement de l'autoloader et du modèle UtilisateurModel
require_once __DIR__ . "/../class/Autoloader.php";
Autoloader::enregistrer();  // Enregistrement de l'autoloader
use model\UtilisateurModel;  // Utilisation du modèle pour l'utilisateur

// Initialisation des variables pour la connexion
$erreur = "";
$email = "";

// Vérification du token CSRF pour sécuriser le formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        throw new Exception("Erreur CSRF : requête invalide.");

    }
}

// Vérification si l'email et le mot de passe ont été envoyés par le formulaire
if (isset($_POST["email"]) && isset($_POST["mdp"])) {
    $email = trim($_POST["email"]);
    $mdp = trim($_POST["mdp"]);

    // Validation des champs
    if ($email == "" || $mdp == "") {
        $erreur = "Tous les champs sont obligatoires.";
    } else {
        try {
            // Vérification du mot de passe avec le modèle UtilisateurModel
            $model = new UtilisateurModel();
            $user = $model->verifierMotDePasseFront($email, $mdp);

            // Si l'utilisateur n'est pas trouvé ou que les informations sont incorrectes
            if (!$user) {
                $erreur = "Email ou mot de passe incorrect.";
            } else {
                // Création de la session avec les informations de l'utilisateur
                $_SESSION["user"] = [
                    "id" => $user->id,
                    "nom" => $user->nom,
                    "prenom" => $user->prenom,
                    "email" => $user->email,
                    "role" => $user->role
                ];

                $_SESSION["role"] = $user->role;

                // Redirection vers la page de profil
                header("Location: " . $url_path . "profil");
                exit();
            }
        } catch (Exception $e) {
            // En cas d'exception, afficher l'erreur
            $erreur = $e->getMessage();
        }
    }
}

// Inclusion des vues de la page de connexion
include($racine_path . "view/header.php");
include($racine_path . "view/connexion.php");
include($racine_path . "view/footer.php");
?>