<?php
/**
 * Contrôleur pour la page des œuvres du musée.
 * Récupère et affiche toutes les œuvres de la base de données.
 * 
 * @category Controleur
 * @package Musée
 * @author Ilissa Ingrachen , Afkir Afkir Hafsa
 */

// Démarre la session pour l'utilisation des variables de session.
session_start();

// Définition du chemin racine pour l'inclusion des fichiers.
$racine_path = "../";  

// Définition du titre de la page.
$titre = "Œuvres - Musée Histoire des Œuvres";
$pageariane = "Œuvres";

// Chargement de l'autoloader pour gérer les classes.
require_once __DIR__ . "/../class/Autoloader.php";
Autoloader::enregistrer(); // Enregistrement de l'autoloader

// Utilisation du modèle OeuvreModel pour récupérer les œuvres.
use model\OeuvreModel;

// Création d'une instance du modèle.
$model = new OeuvreModel();

// Inclusion du header de la page
include($racine_path."view/header.php");

echo "<main>";
echo "<header> Vous êtes sur la page ".$pageariane." </header>";  // Titre de la page

echo "<div class='container'>";
echo "<div class='row'>";

// Bloc pour récupérer les œuvres depuis la base de données
try {
    // Appel du modèle pour récupérer toutes les œuvres
    $oeuvres = $model->chercherAll();

    // Parcours et affichage des œuvres
    foreach ($oeuvres as $o) {
        $id = $o->id;
        $titre_oeuvre = $o->titre;
        $description_courte_oeuvre = $o->description;
        $lien_image_oeuvre = "images/" . $o->image;
        $lien_fiche_oeuvre = "oeuvre-" . $id;

        
        include($racine_path . "view/oeuvre.php");
    }
} catch (Exception $e) {
    echo "<div class='alert alert-danger'>".$e->getMessage()."</div>";
}

echo "</div>";
echo "</div>";
echo "</main>";


include($racine_path."view/footer.php");
?>