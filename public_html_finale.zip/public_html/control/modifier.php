<?php
/**
 * Contrôleur de modification du profil utilisateur.
 * Permet à l'utilisateur connecté de modifier ses informations personnelles, telles que le nom, prénom, email et mot de passe.
 *
 * @category Controleur
 * @package Musée
 * @author Ilissa Ingrachen, Afkir Hafsa
 * @version 1.0
 * @see UtilisateurModel
 * 
 * @param string $racine_path Chemin racine pour l'inclusion des fichiers.
 * @param string $titre Titre de la page.
 * @param string $pageariane Nom de la page dans la navigation.
 * @param string $erreur Message d'erreur si une exception est levée.
 * @param string $message Message de succès (vide ici, à personnaliser si nécessaire).
 * @param string $nom Nom de l'utilisateur.
 * @param string $prenom Prénom de l'utilisateur.
 * @param string $mail Email de l'utilisateur.
 * @param string $role Rôle de l'utilisateur.
 * @param string $ancien_mdp Ancien mot de passe de l'utilisateur.
 * @param string $nouveau_mdp Nouveau mot de passe que l'utilisateur souhaite définir.
 */

// Chemin racine pour l'inclusion des fichiers
$racine_path = "../";

// Titre et page actuelle pour l'affichage dans l'en-tête
$titre = "Modifier profil - Musée Histoire des Œuvres";
$pageariane = "Modifier profil";

// Chargement de l'autoloader et modèle
require_once __DIR__ . "/../class/Autoloader.php";
Autoloader::enregistrer();  // Enregistrement de l'autoloader
use model\UtilisateurModel;  // Utilisation du modèle pour l'utilisateur

// Inclusion du header
include("../view/header.php");  

// Initialisation des variables
$erreur = "";
$message = "";
$nom = "";
$prenom = "";
$mail = "";
$role = "";

// Vérification du token CSRF pour sécuriser le formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        throw new Exception("Erreur CSRF : requête invalide.");

    }
}

try {
    // Récupération des informations de l'utilisateur connecté
    $id_user = (int)$_SESSION["user"]["id"];
    $model = new UtilisateurModel();
    $u = $model->chercherParId($id_user);

    // Traitement du formulaire de modification
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $nom = isset($_POST["nom"]) ? trim($_POST["nom"]) : "";
        $prenom = isset($_POST["prenom"]) ? trim($_POST["prenom"]) : "";
        $mail = isset($_POST["mail"]) ? trim($_POST["mail"]) : "";
        $ancien_mdp = isset($_POST["ancien_mdp"]) ? trim($_POST["ancien_mdp"]) : "";
        $nouveau_mdp = isset($_POST["nouveau_mdp"]) ? trim($_POST["nouveau_mdp"]) : "";

        // Validation des champs
        if ($nom == "" || $prenom == "" || $mail == "") {
            throw new Exception("Tous les champs obligatoires doivent être remplis.");
        }

        // Mise à jour des informations
        $u->nom = $nom;
        $u->prenom = $prenom;
        $u->email = $mail;

        // Si un nouveau mot de passe est fourni, vérification et mise à jour
        if ($nouveau_mdp != "") {
            if ($ancien_mdp == "") {
                throw new Exception("Veuillez saisir votre mot de passe actuel.");
            }
            if (!$u->verifierMotDePasse($ancien_mdp)) {
                throw new Exception("Mot de passe actuel incorrect.");
            }
            $u->mdp = password_hash($nouveau_mdp, PASSWORD_DEFAULT);
        }

        // Mise à jour des données utilisateur dans la base de données
        $model->update($u);

        // Mise à jour des informations dans la session
        $_SESSION["user"]["nom"] = $u->nom;
        $_SESSION["user"]["prenom"] = $u->prenom;
        $_SESSION["user"]["email"] = $u->email;

        // Redirection vers la page de profil
        header("Location: profil");
        exit();
    }

    // Préremplissage des champs du formulaire avec les données actuelles
    $nom = $u->nom;
    $prenom = $u->prenom;
    $mail = $u->email;
    $role = $u->role;
}
catch (Exception $e) {
    // Gestion des erreurs
    $erreur = $e->getMessage();
}

// Inclusion de la vue de modification du profil
include(__DIR__ . "/../view/modifier.php");
?>