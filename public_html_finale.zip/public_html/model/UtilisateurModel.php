<?php
namespace model;

use PDO;
use classes\User;
use interfaces\IModel;
use model\Connexion;
use exception\NotFoundException;
use exception\UtilisateurException;

/**
 * Modèle de gestion des utilisateurs.
 * Permet de gérer les opérations liées aux utilisateurs comme la recherche, l'insertion, la mise à jour et la suppression.
 *
 * @category Model
 * @package Musée
 * @author Ilissa Ingrachen, Afkir Hafsa
 * @version 1.0
 */
class UtilisateurModel implements IModel
{
    /**
     * Vérifier les informations de connexion d'un utilisateur
     *
     * @param string $email Email de l'utilisateur
     * @param string $mdpSaisi Mot de passe de l'utilisateur
     * @return User|false L'objet utilisateur ou false si les informations sont incorrectes
     * @throws UtilisateurException Si une erreur survient lors de la vérification
     */
    public function verifierMotDePasse($email, $mdpSaisi)
    {
        $pdo = Connexion::getInstance();
        $sql = "SELECT * FROM utilisateur WHERE email = :email";
        $stat = $pdo->prepare($sql);
        $stat->execute([':email' => $email]);
        $data = $stat->fetch();

        if (!$data) {
            return false; // Utilisateur non trouvé
        }

        if (password_verify($mdpSaisi, $data['mdp']) && $data['role'] === 'admin') {
            return new User(
                $data['id'],
                $data['nom'],
                $data['prenom'],
                $data['email'],
                $data['mdp'],
                $data['role']
            );
        }
        return false;
    }

    /**
     * Vérifier les informations de connexion pour un utilisateur général
     *
     * @param string $email Email de l'utilisateur
     * @param string $mdpSaisi Mot de passe de l'utilisateur
     * @return User|false L'objet utilisateur ou false si les informations sont incorrectes
     */
    public function verifierMotDePasseFront($email, $mdpSaisi)
    {
        $pdo = Connexion::getInstance();
        $sql = "SELECT * FROM utilisateur WHERE email = :email";
        $stat = $pdo->prepare($sql);
        $stat->execute([':email' => $email]);
        $data = $stat->fetch(PDO::FETCH_ASSOC);

        if (!$data) {
            return false;
        }

        if ($mdpSaisi == $data['mdp'] || password_verify($mdpSaisi, $data['mdp'])) {
            return new User(
                $data['id'],
                $data['nom'],
                $data['prenom'],
                $data['email'],
                $data['mdp'],
                $data['role']
            );
        }

        return false;
    }

    /**
     * Chercher un utilisateur par son ID
     *
     * @param int $id Identifiant de l'utilisateur
     * @return User L'objet utilisateur
     * @throws UtilisateurException Si l'utilisateur n'est pas trouvé
     */
    public function chercherParId($id)
    {
        $pdo = Connexion::getInstance();
        $sql = "SELECT id, nom, prenom, email, mdp, role, image FROM utilisateur WHERE id = :id";
        $stat = $pdo->prepare($sql);
        $stat->bindValue(":id", (int)$id, PDO::PARAM_INT);
        $stat->execute();
        $data = $stat->fetch();

        if (!$data) {
            throw new UtilisateurException("Utilisateur non trouvé");
        }

        return new User(
            $data['id'],
            $data['nom'],
            $data['prenom'],
            $data['email'],
            $data['mdp'],
            $data['role'],
            $data['image']
        );
    }

    /**
     * Insérer un nouvel utilisateur
     *
     * @param User $objet L'objet utilisateur à insérer
     * @return User L'objet utilisateur inséré avec son ID
     * @throws UtilisateurException Si une erreur survient lors de l'insertion
     */
    public function insert($objet)
    {
        $pdo = Connexion::getInstance();
        $sql = "INSERT INTO utilisateur (nom, prenom, email, mdp, role, image) VALUES (:nom, :prenom, :email, :mdp, :role, :image)";
        $stat = $pdo->prepare($sql);
        $stat->execute([
            ':nom' => $objet->nom,
            ':prenom' => $objet->prenom,
            ':email' => $objet->email,
            ':mdp' => $objet->mdp,
            ':role' => $objet->role,
            ':image' => $objet->image
        ]);
        $objet->id = $pdo->lastInsertId();
        return $objet;
    }

    /**
     * Mettre à jour un utilisateur existant
     *
     * @param User $objet L'objet utilisateur à mettre à jour
     * @return bool Retourne true si la mise à jour a réussi
     * @throws UtilisateurException Si une erreur survient lors de la mise à jour
     */
    public function update($objet)
    {
        $pdo = Connexion::getInstance();
        $sql = "UPDATE utilisateur SET nom = :nom, prenom = :prenom, email = :email, mdp = :mdp, image = :image WHERE id = :id";
        $stat = $pdo->prepare($sql);
        $stat->execute([
            ':nom' => $objet->nom,
            ':prenom' => $objet->prenom,
            ':email' => $objet->email,
            ':mdp' => $objet->mdp,
            ':id' => $objet->id,
            ':image' => $objet->image
        ]);
        return $stat->rowCount() > 0;
    }

    /**
     * Chercher tous les utilisateurs
     *
     * @return User[] Liste des utilisateurs
     * @throws UtilisateurException Si une erreur survient lors de la récupération
     */
    public function chercherAll()
    {
        $pdo = Connexion::getInstance();
        $sql = "SELECT * FROM utilisateur";
        $stat = $pdo->prepare($sql);
        $stat->execute();
        $rows = $stat->fetchAll(PDO::FETCH_ASSOC);
        $liste = [];
        foreach ($rows as $row) {
            $u = new User(
                $row['id'],
                $row['nom'],
                $row['prenom'],
                $row['email'],
                $row['mdp'],
                $row['role'],
                $row['image']
            );
            $liste[] = $u;
        }
        return $liste;
    }

    /**
     * Supprimer un utilisateur existant
     *
     * @param int $id L'identifiant de l'utilisateur à supprimer
     * @return bool Retourne true si la suppression a réussi
     * @throws UtilisateurException Si une erreur survient lors de la suppression
     */
    public function delete($id)
    {
        $pdo = Connexion::getInstance();
        $sql = "DELETE FROM utilisateur WHERE id = :id";
        $stat = $pdo->prepare($sql);
        $stat->execute([':id' => $id]);
        return true;
    }

    /**
     * Récupérer le dernier utilisateur ajouté
     *
     * @return User L'objet utilisateur ajouté
     * @throws UtilisateurException Si aucun utilisateur n'est trouvé
     */
    public function getLast()
    {
        $pdo = Connexion::getInstance();
        $sql = "SELECT id, nom, prenom, email, mdp, role, image FROM utilisateur ORDER BY id DESC LIMIT 1";
        $stat = $pdo->prepare($sql);
        $stat->execute();
        $data = $stat->fetch(PDO::FETCH_ASSOC);
        if (!$data) {
            throw new UtilisateurException("Aucun utilisateur trouvé");
        }
        return new User(
            $data['id'],
            $data['nom'],
            $data['prenom'],
            $data['email'],
            $data['mdp'],
            $data['role'],
            $data['image']
        );
    }
}
?>