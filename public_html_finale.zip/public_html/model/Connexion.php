<?php
/**
 * Classe Connexion pour la gestion de la connexion à la base de données.
 * Cette classe implémente le pattern Singleton afin d'assurer qu'il n'y ait qu'une seule connexion à la base de données.
 * Elle permet de récupérer l'instance PDO de la base de données PostgreSQL.
 * 
 * @category Modèle
 * @package Musée
 * @author Ilissa Ingrachen, Afkir Hafsa
 * @version 1.0
 */
namespace model;

use PDO;
use PDOException;

class Connexion
{
    /**
     * Instance unique de PDO
     *
     * @var PDO|null
     */
    private static $pdo = null;

    /**
     * Récupère l'instance PDO de la base de données.
     * Si l'instance n'existe pas, une nouvelle connexion est établie.
     *
     * @return PDO
     * @throws ConnexionException si une erreur se produit lors de la connexion
     */
    public static function getInstance()
    {
        if (self::$pdo === null) {
            try {
                // Paramètres de connexion à la base de données
                $host = "pedago01c.univ-avignon.fr";
                $port = "5432";
                $dbname = "etd";
                $user = "uapv2500983";
                $password = "hello";

                // Création de l'instance PDO pour la connexion à la base de données PostgreSQL
                self::$pdo = new PDO(
                    "pgsql:host=$host;port=$port;dbname=$dbname",
                    $user,
                    $password
                );
            } catch (PDOException $e) {
                // Si une erreur se produit lors de la connexion, une exception est lancée
                throw new ConnexionException("Erreur conn:".$e->getMessage());
            }
        }
        return self::$pdo;
    }

    /**
     * Ferme la connexion à la base de données en mettant l'instance PDO à null.
     *
     * @return void
     */
    public static function close()
    {
        self::$pdo = null;
    }
}
?>