<?php
namespace model;

use interfaces\IModel;
use classes\Oeuvre;
use classes\Artiste;

use model\Connexion;
use model\ArtisteModel;

use exception\NotFoundException;
use exception\OeuvreException;
use exception\ArtisteException;
use PDO;

/**
 * Modèle pour gérer les œuvres dans la base de données.
 * Permet de chercher, ajouter, modifier, et supprimer des œuvres.
 * 
 * @category Model
 * @package Musée
 * @author Ilissa Ingrachen, Afkir Hafsa
 * @version 1.0
 */
class OeuvreModel implements IModel
{
    /**
     * Chercher une oeuvre par son ID.
     *
     * @param int $id Identifiant de l'œuvre
     * @return Oeuvre L'objet œuvre trouvé
     * @throws NotFoundException Si l'œuvre n'est pas trouvée
     */
    public function chercher($id)
    {
        $pdo = Connexion::getInstance();
        $sql = "SELECT * FROM oeuvre WHERE id = :id";
        $stat = $pdo->prepare($sql);
        $stat->bindValue(":id", (int)$id, PDO::PARAM_INT);
        $stat->execute();
        $ligne = $stat->fetch();
        if (!$ligne) {
            throw new NotFoundException("Oeuvre non trouvée");
        }
        $oeuvre = new Oeuvre(
            $ligne["id"],
            $ligne["titre"],
            $ligne["type"],
            $ligne["date_creation"],
            $ligne["auteur"],
            $ligne["description"],
            $ligne["image"]
        );
        $artisteModel = new ArtisteModel();
        $oeuvre->auteur = $artisteModel->chercher($oeuvre->auteur);
        return $oeuvre;
    }

    /**
     * Chercher toutes les œuvres dans la base de données.
     * 
     * @return Oeuvre[] Liste des objets œuvre
     */
    public function chercherAll()
    {
        $pdo = Connexion::getInstance();
        $stat = $pdo->query("SELECT id, titre, type, date_creation, auteur, description, image FROM oeuvre ORDER BY titre");
        $liste = [];
        $artisteModel = new ArtisteModel();
        while ($ligne = $stat->fetch()) {
            $oeuvre = new Oeuvre(
                $ligne["id"],
                $ligne["titre"],
                $ligne["type"],
                $ligne["date_creation"],
                $ligne["auteur"],
                $ligne["description"],
                $ligne["image"]
            );
            // Charger l'artiste pour l'œuvre
            $oeuvre->auteur = $artisteModel->chercher($oeuvre->auteur);
            $liste[] = $oeuvre;
        }
        return $liste;
    }

    /**
     * Récupérer les œuvres d'un artiste.
     * 
     * @param int $artisteId L'identifiant de l'artiste
     * @return Oeuvre[] Liste des œuvres de l'artiste
     */
    public function getOeuvresByArtiste($artisteId)
    {
        $pdo = Connexion::getInstance();
        $stat = $pdo->prepare("SELECT id, titre, type, date_creation, auteur, description, image FROM oeuvre WHERE auteur = :auteur ORDER BY titre");
        $stat->bindValue(":auteur", (int)$artisteId, PDO::PARAM_INT);
        $stat->execute();
        $liste = [];
        $artisteModel = new ArtisteModel();
        while ($ligne = $stat->fetch()) {
            $oeuvre = new Oeuvre(
                $ligne["id"],
                $ligne["titre"],
                $ligne["type"],
                $ligne["date_creation"],
                $ligne["auteur"],
                $ligne["description"],
                $ligne["image"]
            );
            $oeuvre->auteur = $artisteModel->chercher($oeuvre->auteur);
            $liste[] = $oeuvre;
        }
        return $liste;
    }

    /**
     * Insérer une nouvelle œuvre dans la base de données.
     * 
     * @param Oeuvre $objet L'objet œuvre à ajouter
     * @return Oeuvre L'objet œuvre ajouté avec son identifiant
     * @throws OeuvreException Si l'insertion échoue
     * @throws ArtisteException Si l'artiste de l'œuvre n'est pas trouvé
     */
    public function insert($objet)
    {
        $pdo = Connexion::getInstance();
        $artisteModel = new ArtisteModel();
        $artiste = $artisteModel->chercher($objet->auteur);
        if (!$artiste) {
            throw new ArtisteException("Artiste non trouvé, impossible d'ajouter l'œuvre");
        }
        $sql = "INSERT INTO oeuvre(titre, type, date_creation, auteur, description, image)
                VALUES(:titre, :type, :date_creation, :auteur, :description, :image)";
        $stat = $pdo->prepare($sql);
        $stat->bindValue(":titre", $objet->titre);
        $stat->bindValue(":type", $objet->type);
        $stat->bindValue(":date_creation", $objet->date_creation);
        $stat->bindValue(":auteur", (int)$artiste->id, PDO::PARAM_INT);
        $stat->bindValue(":description", $objet->description);
        $stat->bindValue(":image", $objet->image);
        if (!$stat->execute()) {
            throw new OeuvreException("Erreur lors de l'ajout de l'œuvre");
        }
        $objet->id = $pdo->lastInsertId();
        return $objet;
    }

    /**
     * Mettre à jour une œuvre existante.
     * 
     * @param Oeuvre $objet L'objet œuvre à mettre à jour
     * @return bool Retourne vrai si la mise à jour a réussi
     * @throws OeuvreException Si la mise à jour échoue
     * @throws ArtisteException Si l'artiste de l'œuvre n'est pas trouvé
     */
    public function update($objet)
    {
        $pdo = Connexion::getInstance();
        $artisteModel = new ArtisteModel();
       $artiste = $artisteModel->chercher($objet->auteur);
        if (!$artiste) {
            throw new ArtisteException("Artiste non trouvé");
        }
        $sql = "UPDATE oeuvre
                SET titre = :titre,
                    type = :type,
                    date_creation = :date_creation,
                    auteur = :auteur,
                    description = :description,
                    image = :image
                WHERE id = :id";
        $stat = $pdo->prepare($sql);
        $stat->bindValue(":titre", $objet->titre);
        $stat->bindValue(":type", $objet->type);
        $stat->bindValue(":date_creation", $objet->date_creation);
        $stat->bindValue(":auteur", (int)$artiste->id, PDO::PARAM_INT);
        $stat->bindValue(":description", $objet->description);
        $stat->bindValue(":id", (int)$objet->id, PDO::PARAM_INT);
        $stat->bindValue(":image", $objet->image);
        if (!$stat->execute()) {
            throw new OeuvreException("Erreur lors de la modification de l'œuvre");
        }
        return true;
    }

    /**
     * Supprimer une œuvre existante.
     * 
     * @param int $id L'identifiant de l'œuvre à supprimer
     * @return bool Retourne vrai si la suppression a réussi
     * @throws OeuvreException Si la suppression échoue
     */
    public function delete($id)
    {
        $pdo = Connexion::getInstance();
        $sql = "DELETE FROM oeuvre WHERE id = :id";
        $stat = $pdo->prepare($sql);
        $stat->bindValue(":id", (int)$id, PDO::PARAM_INT);
        if (!$stat->execute()) {
            throw new OeuvreException("Erreur lors de la suppression de l'œuvre");
        }
        return true;
    }
}
?>