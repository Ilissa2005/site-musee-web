<?php
namespace model;
use classes\Artiste; 
use interfaces\IModel;
use PDO;
use exception\NotFoundException;
use exception\ArtisteException; 
class ArtisteModel implements IModel
{
//get
//renvoie la liste d'oeuvre
//delete add modifier
//existe
//exposer??? peut etre pas

    /**
     * Chercher un artiste par son nolm et prénom
     * @param string $nomComplet
     * @return Artiste ou null si elle n'est pas trouvé
     */
    public function chercherParNom($nomComplet)
        {
        $pdo = Connexion::getInstance();
        // Séparer le nom complet en parties
        $parts = explode(" ", trim($nomComplet), 2);
        if (count($parts) == 1) {
            // si  part est nom, prenom vide
            $nom = $parts[0];
            $prenom = "";
            $sql = "SELECT * FROM artiste WHERE nom = :nom AND prenom = :prenom";
            $stat = $pdo->prepare($sql);
            $stat->bindValue(":nom", $nom);
            $stat->bindValue(":prenom", $prenom);
            $stat->execute();
            $ligne = $stat->fetch();
            if ($ligne) {
                return new Artiste(
                    $ligne["id"],
                    $ligne["nom"],
                    $ligne["prenom"],
                    $ligne["bio"],
                    $ligne["image"]
                );
            }
            return null;
        } elseif (count($parts) == 2) {
            $part1 = $parts[0];
            $part2 = $parts[1];
            $sql = "SELECT * FROM artiste WHERE nom = :nom AND prenom = :prenom";
            $stat = $pdo->prepare($sql);
            $stat->bindValue(":nom", $part2);
            $stat->bindValue(":prenom", $part1);
            $stat->execute();
            $ligne = $stat->fetch();
            if ($ligne) {
                return new Artiste(
                    $ligne["id"],
                    $ligne["nom"],
                    $ligne["prenom"],
                    $ligne["bio"],
                    $ligne["image"]
                );
            }
            // Si on trouve pas essayer part1 comme nom, part2 comme prénom
            $stat->bindValue(":nom", $part1);
            $stat->bindValue(":prenom", $part2);
            $stat->execute();
            $ligne = $stat->fetch();
            if ($ligne) {
                return new Artiste(
                    $ligne["id"],
                    $ligne["nom"],
                    $ligne["prenom"],
                    $ligne["bio"],
                    $ligne["image"]
                );
            }
            return null;
        } else {
            return null;
        }
    }
    /**
     * Chercher un artiste par son ID
     * @param int $id
     * @return Artiste
     * @throws NotFoundException si l'artiste n'est pas trouvé
     */
    public function chercher($id)
        {
            $pdo = Connexion::getInstance();
            $sql = "SELECT * FROM artiste WHERE id = :id";
            $stat = $pdo->prepare($sql);
            $stat->bindValue(":id", (int)$id, PDO::PARAM_INT);
            $stat->execute();
            $ligne = $stat->fetch();
            if (!$ligne) {
                try {
                    throw new NotFoundException("Artiste non trouvé");
                } catch (NotFoundException $e) {
                    echo $e->getMessage();
                    echo $e->getCode();
                }
            }
            return new Artiste(
                $ligne["id"],
                $ligne["nom"],
                $ligne["prenom"],
                $ligne["bio"],
                $ligne["image"]
            );
        }
    /**
     * Chercher tous les artistes
     * @return Artiste[]
     */

    public function chercherAll()
    {
        $pdo = Connexion::getInstance();
        $stat = $pdo->query("SELECT id, nom, prenom, bio, image FROM artiste ORDER BY nom, prenom");
        $liste = [];
        while ($ligne = $stat->fetch()) {
            $liste[] = new Artiste(
                $ligne["id"],
                $ligne["nom"],
                $ligne["prenom"],
                $ligne["bio"],
                $ligne["image"]
            );
        }

        return $liste;
    }
    /**
     * Insert un nouvel artiste
     * @param Artiste $objet
     * @return Artiste
     * @throws ArtisteException si une erreur survient lors de l'insertion
     */
    public function insert($objet)
    {
        $pdo = Connexion::getInstance();
        $sql = "INSERT INTO artiste(nom, prenom, bio, image)
                VALUES(:nom, :prenom, :bio, :image)";
        $stat = $pdo->prepare($sql);
        $stat->bindValue(":nom", $objet->nom);
        $stat->bindValue(":prenom", $objet->prenom);
        $stat->bindValue(":bio", $objet->bio);
        $stat->bindValue(":image", $objet->image);
        if (!$stat->execute()) {
            throw new ArtisteException("Erreur lors de l'ajout de l'artiste");
        }
        $objet->id = $pdo->lastInsertId();
        return $objet;
    }
    /**
     * Mettre à jour un artiste existant
     * @param Artiste $objet
     * @return bool
     * @throws ArtisteException si une erreur survient lors de la mise à jour
     */
    public function update($objet)
    {
        $pdo = Connexion::getInstance();
        $sql = "UPDATE artiste
                SET nom = :nom, prenom = :prenom, bio = :bio, image = :image
                WHERE id = :id";
        $stat = $pdo->prepare($sql);
        $stat->bindValue(":nom", $objet->nom);
        $stat->bindValue(":prenom", $objet->prenom);
        $stat->bindValue(":bio", $objet->bio);
        $stat->bindValue(":image", $objet->image);
        $stat->bindValue(":id", (int)$objet->id, PDO::PARAM_INT);

        if (!$stat->execute()) {
            try {
                throw new ArtisteException("Erreur lors de la modification de l'artiste");
            } catch (ArtisteException $e) {
                echo $e->getMessage();
                echo $e->getCode();
            }
        }

        return true;
    }
    /**
     * Supprimer un artiste existant
     * @param int $id
     * @return bool
     * @throws ArtisteException si une erreur survient lors de la suppression
     */
    public function delete($id)
    {
        $pdo = Connexion::getInstance();

        $sql = "DELETE FROM artiste WHERE id = :id";
        $stat = $pdo->prepare($sql);
        $stat->bindValue(":id", (int)$id, PDO::PARAM_INT);

        if (!$stat->execute()) {
            try {
                throw new ArtisteException("Erreur lors de la suppression de l'artiste");
            } catch (ArtisteException $e) {
                echo $e->getMessage();
                echo $e->getCode();
            }
        }

        return true;
    }
    //Pour la fct de liste des oeuvres
    public function getOeuvresArtiste($id)
    {
        $oeuvreModel = new OeuvreModel();
        return $oeuvreModel->getOeuvresByArtiste($id);
    }
}

?>