<?php
/**
 * Contrôleur de la page d'accueil.
 * Charge et affiche la page d'accueil du site Musée Histoire des Œuvres.
 * Inclut les fichiers nécessaires pour l'en-tête, le contenu principal et le pied de page.
 * 
 * @category Contrôleur
 * @package Musée
 * @author Ilissa Ingrachen, Afkir Hafsa
 * @version 1.0
 * 
 * Le fichier charge les vues suivantes :
 * - `header.php` : l'en-tête du site
 * - `accueil.php` : la page d'accueil du site
 * - `footer.php` : le pied de page du site
 */
$racine_path = "./";  // Chemin de base du projet
$titre = "Accueil";   // Titre de la page
$pageariane = "Accueil";  // Page actuelle

// Inclure les fichiers nécessaires
include("view/header.php");
include("view/accueil.php");
include("view/footer.php");
?>